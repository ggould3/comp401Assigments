package main;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@Tags({"Plus"})
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Input"})
@EditablePropertyNames({"Input"})

public class PlusToken implements TokenInterface{

	static String plusToken;
	
	//Constructor 1
	public PlusToken(){
		plusToken = "";
	}
	
	//Constructor 2
	public PlusToken(String pInput){
		plusToken = pInput;
	}
	
	//Setter
	public void setInput(String pInput){
		plusToken = pInput;
	}
	
	//Getter for token
	public String getInput(){
		return plusToken;
	}
}
