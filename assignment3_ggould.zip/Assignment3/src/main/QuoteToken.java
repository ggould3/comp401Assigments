package main;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@Tags({"Quote"})
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Input", "Value"})
@EditablePropertyNames({"Input"})

public class QuoteToken implements QuoteInterface{

	static String quoteString;
	static String quoteToken;
	
	//Constructor 1
	public QuoteToken(){
		quoteToken = "";
	}
	
	//Constructor 2
	public QuoteToken(String qInput){
		quoteString = qInput;
		QuoteToken.createQuoteToken(quoteString);
	}
	
	//Setter
	public void setInput(String qInput){
		quoteString = qInput;
		QuoteToken.createQuoteToken(quoteString);
	}
	
	//Converter
	private static void createQuoteToken(String qString){
		quoteToken = qString.substring(1,qString.length()-1);
	}
	
	//Getter for token
	public String getValue(){
		return quoteToken;
	}
	
	//Getter for raw input
	public String getInput(){
		return quoteString;
	}
}
