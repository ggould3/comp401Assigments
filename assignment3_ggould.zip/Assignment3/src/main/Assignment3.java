package main;

import java.util.Scanner;

public class Assignment3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("Please enter your command separated by spaces. Use '.' to terminate.");
		ScannerInterface scannerBean = new ScannerBean();
		
		while (true){
			scannerBean.setScannedString(keyboard.nextLine());
		}
	}

}
