package main;

public interface ScannerInterface {
	void setScannedString(String newInput);
	String getScannedString();
	
	void createNumberObject(String newInput);
	void createWordObject(String newInput);
	void createQuoteObject(String newInput);
}
