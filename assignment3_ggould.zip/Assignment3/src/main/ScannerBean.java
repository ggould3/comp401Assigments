package main;

public class ScannerBean implements ScannerInterface{
	static String scannedString;
	
	public void setScannedString(String inputString){
		scannedString = inputString;
		String input = scannedString;
		ScannerInterface scannerBean = new ScannerBean();
		
		int index = 0;
		int subStart;
		int subEnd;
		
		while (index < input.length()){
			if (input.charAt(index) == '.'){ 	//Terminates on '.'
				System.out.println("Terminating program.");
				System.exit(0);
			}else if (input.charAt(index) == '{'){ 	//Grabs Start Tokens
				subStart = index;
				subEnd = index + 1;
				TokenInterface mySToken = new StartToken(input.substring(subStart,subEnd));
				String startToken = mySToken.getInput();
				System.out.println(mySToken);
				System.out.println(startToken);
				index += 1;
			}else if (input.charAt(index) == '}'){ 	//Grabs End Tokens
				subStart = index;
				subEnd = index + 1;
				TokenInterface myEToken = new EndToken(input.substring(subStart,subEnd));
				String endToken = myEToken.getInput();
				System.out.println(myEToken);
				System.out.println(endToken);
				index += 1;
			}else if (input.charAt(index) == '+'){ 	//Grabs Plus Tokens
				subStart = index;
				subEnd = index + 1;
				TokenInterface myPToken = new PlusToken(input.substring(subStart,subEnd));
				String plusToken = myPToken.getInput();
				System.out.println(myPToken);
				System.out.println(plusToken);
				index += 1;
			}else if (input.charAt(index) == '-'){ 	//Grabs Minus Tokens
				subStart = index;
				subEnd = index + 1;
				TokenInterface myMToken = new MinusToken(input.substring(subStart,subEnd));
				String minusToken = myMToken.getInput();
				System.out.println(myMToken);
				System.out.println(minusToken);
				index += 1;
			}else if (Character.isDigit(input.charAt(index))){ 	//Grabs Numbers
				subStart = index;
				int nextChar = index + 1;
				
				if (index == (input.length()-1)){
					subEnd = nextChar;					
					scannerBean.createNumberObject(input.substring(subStart,subEnd));					
					index = nextChar;
					break;
				}
				
				while (nextChar < input.length()){
					if(Character.isDigit(input.charAt(nextChar)) && nextChar == (input.length()-1)){
						subEnd = nextChar+1;						
						scannerBean.createNumberObject(input.substring(subStart,subEnd));						
						index = nextChar + 1;
						break;
					}else if (Character.isDigit(input.charAt(nextChar)) && nextChar < input.length()){
						nextChar++;
					}else{
						subEnd = nextChar;						
						scannerBean.createNumberObject(input.substring(subStart,subEnd));						
						index = nextChar;
						break;
					}
				}
			}else if(input.charAt(index)=='"'){ 	//Grabs Quotes
				subStart = index;
				int nextChar = index + 1;
				
				while (nextChar < input.length()){
					if (input.charAt(nextChar) == '"'){
						subEnd = nextChar;
						scannerBean.createQuoteObject(input.substring(subStart,subEnd+1));
						index = nextChar + 1;
						break;
					}else if (nextChar == (input.length()-1) && !(input.charAt(nextChar) == '"')){
						System.out.println("Error: no closing quotation found.");
						System.exit(0);
					}else{
						nextChar++;
					}
				}
			}else if (Character.isLetter(input.charAt(index))){ 	//Grabs Words
				subStart = index;
				int nextChar = index + 1;
				
				if (index == (input.length()-1)){
					subEnd = nextChar;
					scannerBean.createWordObject(input.substring(subStart,subEnd));
					index = nextChar;
					break;
				}
				
				while (nextChar < input.length()){
					if(Character.isLetter(input.charAt(nextChar)) && nextChar == (input.length()-1)){
						subEnd = nextChar+1;
						scannerBean.createWordObject(input.substring(subStart,subEnd));
						index = nextChar + 1;
						break;
					}else if (Character.isLetter(input.charAt(nextChar)) && nextChar < input.length()){
						nextChar++;
					}else{
						subEnd = nextChar;
						scannerBean.createWordObject(input.substring(subStart,subEnd));
						index = nextChar;
						break;
					}
				}
			}else{
				index++;
			}
		}
	}
	
	public String getScannedString(){
		return scannedString;
	}
	
	public void createNumberObject(String inputSubstring){
		NumberInterface myNumToken = new NumberToken(inputSubstring);
		int numberToken = myNumToken.getValue();
		String numberString = myNumToken.getInput();
		System.out.println(myNumToken);
		System.out.println(numberString);
		System.out.println(numberToken);
	}
	
	public void createWordObject(String inputSubstring){
		WordInterface myWToken = new WordToken(inputSubstring);
		String wordToken = myWToken.getValue();
		String wordString = myWToken.getInput();
		System.out.println(myWToken);
		System.out.println(wordString);
		System.out.println(wordToken);
	}
	
	public void createQuoteObject(String inputSubstring){
		QuoteInterface myQToken = new QuoteToken(inputSubstring);
		String quoteToken = myQToken.getValue();
		String quoteString = myQToken.getInput();
		System.out.println(myQToken);
		System.out.println(quoteString);
		System.out.println(quoteToken);
	}
}