package main;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@Tags({"Number"})
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Input", "Value"})
@EditablePropertyNames({"Input"})

public class NumberToken implements NumberInterface{

	static String numberString;
	static int numberToken;
	
	//Constructor 1
	public NumberToken(){
		numberToken = 0;
	}
	
	//Constructor 2
	public NumberToken(String numInput){
		numberString = numInput;
		NumberToken.createNumberToken(numberString);
	}
	
	//Setter
	public void setInput(String numInput){
		numberString = numInput;
		NumberToken.createNumberToken(numberString);
	}
	
	//Converter
	private static void createNumberToken(String numString){
		numberToken = Integer.parseInt(numString);
	}
	
	//Getter for token
	public int getValue(){
		return numberToken;
	}
	
	//Getter for raw input
	public String getInput(){
		return numberString;
	}
}
