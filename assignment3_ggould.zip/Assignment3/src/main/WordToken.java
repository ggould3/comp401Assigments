package main;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@Tags({"Word"})
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Input", "Value"})
@EditablePropertyNames({"Input"})

public class WordToken implements WordInterface{

	static String wordString;
	static String wordToken;
	
	//Constructor 1
	public WordToken(){
		wordToken = "";
	}
	
	//Constructor 2
	public WordToken(String wInput){
		wordString = wInput;
		WordToken.createWordToken(wordString);
	}
	
	//Setter
	public void setInput(String wInput){
		wordString = wInput;
		WordToken.createWordToken(wordString);
	}
	
	//Converter
	private static void createWordToken(String wString){
		wordToken = (wString.toLowerCase());
	}
	
	//Getter for token
	public String getValue(){
		return wordToken;
	}
	
	//Getter for raw input
	public String getInput(){
		return wordString;
	}
}
