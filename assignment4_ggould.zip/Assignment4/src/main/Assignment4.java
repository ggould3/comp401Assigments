package main;

import util.misc.ThreadSupport;
import bus.uigen.OEFrame;
import bus.uigen.ObjectEditor;

public class Assignment4 {

	public static void main(String[] args) {
		ScannerInterface scannerBean = new ScannerBean();
		
		OEFrame editor = ObjectEditor.edit(scannerBean);
		scannerBean.setScannedString("MoVe 050 { saY \"hi!\" } ");
		editor.refresh();
		ThreadSupport.sleep(3000);
		scannerBean.setScannedString("REPEAT -09 + rotateLEFTarm \"say\" {undo} 008 ");
		editor.refresh();
		ThreadSupport.sleep(3000); // 3 second delay should be enough
	}
}
