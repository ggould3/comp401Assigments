package main;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@Tags({"rotateLeftArm"})
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Input", "Value"})
@EditablePropertyNames({"Input"})

public class CommandRotateLeftArm extends WordToken{

	public CommandRotateLeftArm(String input) {
		wordString = input;
		wordToken = input.toLowerCase();
	}

}
