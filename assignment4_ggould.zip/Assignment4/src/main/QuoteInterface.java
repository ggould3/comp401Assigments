package main;

public interface QuoteInterface extends TokenInterface{
	String getValue();
}
