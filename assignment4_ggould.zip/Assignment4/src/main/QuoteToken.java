package main;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@Tags({"Quote"})
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Input", "Value"})
@EditablePropertyNames({"Input"})

public class QuoteToken implements QuoteInterface{

	String quoteString;
	String quoteToken;
	
	//Constructor 1
	public QuoteToken(){
		quoteToken = "";
	}
	
	//Constructor 2
	public QuoteToken(String qInput){
		quoteString = qInput;
		quoteToken = qInput.substring(1,qInput.length()-1);
	}
	
	//Setter
	public void setInput(String qInput){
		quoteString = qInput;
		quoteToken = qInput.substring(1,qInput.length()-1);
	}
	
	//Getter for token
	public String getValue(){
		return quoteToken;
	}
	
	//Getter for raw input
	public String getInput(){
		return quoteString;
	}
}
