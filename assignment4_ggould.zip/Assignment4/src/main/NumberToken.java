package main;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@Tags({"Number"})
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Input", "Value"})
@EditablePropertyNames({"Input"})

public class NumberToken implements NumberInterface{

	String numberString;
	int numberToken;
	
	//Constructor 1
	public NumberToken(){
		numberToken = 0;
	}
	
	//Constructor 2
	public NumberToken(String numInput){
		numberString = numInput;
		numberToken = Integer.parseInt(numInput);
	}
	
	//Setter
	public void setInput(String numInput){
		numberString = numInput;
		numberToken = Integer.parseInt(numInput);
	}
	
	//Getter for token
	public int getValue(){
		return numberToken;
	}
	
	//Getter for raw input
	public String getInput(){
		return numberString;
	}
}
