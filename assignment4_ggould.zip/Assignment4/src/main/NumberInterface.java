package main;

public interface NumberInterface extends TokenInterface{
	int getValue();
}
