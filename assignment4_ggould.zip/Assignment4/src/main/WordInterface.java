package main;

public interface WordInterface extends TokenInterface{
	String getValue();
}
