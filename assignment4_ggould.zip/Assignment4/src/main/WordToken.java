package main;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@Tags({"Word"})
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Input", "Value"})
@EditablePropertyNames({"Input"})

public class WordToken implements WordInterface{

	String wordString;
	String wordToken;
	
	//Constructor 1
	public WordToken(){
		wordToken = "";
	}
	
	//Constructor 2
	public WordToken(String wInput){
		wordString = wInput;
		wordToken = (wInput.toLowerCase());
	}
	
	//Setter
	public void setInput(String wInput){
		wordString = wInput;
		wordToken = (wInput.toLowerCase());
	}
	
	//Getter for token
	public String getValue(){
		return wordToken;
	}
	
	//Getter for raw input
	public String getInput(){
		return wordString;
	}
}
