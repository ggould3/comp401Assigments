package grail.tokens;

public interface WordInterface extends TokenInterface{
	String getValue();
}
