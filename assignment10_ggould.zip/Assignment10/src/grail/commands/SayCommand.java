package grail.commands;

import mp.bridge.BridgeInterface;

public class SayCommand implements Runnable{

	BridgeInterface scene;
	String text;
	
	public SayCommand(BridgeInterface scene, String text){
		this.scene = scene;
		this.text = text;
	}
	
	public void run() {
		scene.sayString(text);
	}

}
