package grail.commands;

import mp.animator.AvatarAnimator;
import grail.graphics.AvatarInterface;
import util.annotations.Tags;

@Tags({"AnimatingCommand"})
public class AnimateCommand implements Runnable{

	AvatarInterface avatar;
	
	public AnimateCommand(AvatarInterface avatar){
		this.avatar = avatar;
	}
	
	public void run(){
		AvatarAnimator.animateAvatar(avatar);
	}
}
