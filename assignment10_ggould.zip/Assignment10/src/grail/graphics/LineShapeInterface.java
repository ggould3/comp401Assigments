package grail.graphics;

public interface LineShapeInterface extends BoundedShapeInterface{

}
