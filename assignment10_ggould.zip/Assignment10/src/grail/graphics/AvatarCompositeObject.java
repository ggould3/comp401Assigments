package grail.graphics;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Head", "Arms", "Body", "Legs", "Text"})
@EditablePropertyNames({"Text"})

@Tags({"Avatar"})
public class AvatarCompositeObject implements AvatarInterface{

	ImageShapeInterface head;
	AngleInterface arms;
	LineShapeInterface body;
	AngleInterface legs;
	StringShapeInterface text;
	
	int scale = 1;
	final static int LINE_LENGTH = 40;
	final static int INIT_X = 40;
	final static int INIT_Y = 20;
	
	public AvatarCompositeObject(String HeadFileName){
		head = new HeadObject(HeadFileName, INIT_X, INIT_Y);
			int headWidth = head.getWidth();
			int headHeight = head.getHeight();
		arms = new AngleCompositeObject((headWidth/2+40), headHeight+20, LINE_LENGTH, LINE_LENGTH, -1*LINE_LENGTH, LINE_LENGTH);
		body = new LineObject((headWidth/2+INIT_X), headHeight+INIT_Y, 0, 2*LINE_LENGTH);
		legs = new AngleCompositeObject((headWidth/2)+INIT_X, (headHeight+2*LINE_LENGTH+INIT_Y), LINE_LENGTH, LINE_LENGTH, -1*LINE_LENGTH, LINE_LENGTH);
		text = new StringShapeObject("Hello There!", headWidth+INIT_X, INIT_Y);
	}
	
	public AvatarCompositeObject(String HeadFileName, int initX, int initY){
		head = new HeadObject(HeadFileName, initX, initY);
			int headWidth = head.getWidth();
			int headHeight = head.getHeight();
		arms = new AngleCompositeObject((headWidth/2+initX), headHeight+initY, LINE_LENGTH, LINE_LENGTH, -1*LINE_LENGTH, LINE_LENGTH);
		body = new LineObject((headWidth/2+initX), headHeight+initY, 0, 2*LINE_LENGTH);
		legs = new AngleCompositeObject((headWidth/2)+initX, (headHeight+80+initY), LINE_LENGTH, LINE_LENGTH, -1*LINE_LENGTH, LINE_LENGTH);
		text = new StringShapeObject("", headWidth+initX, initY);
	}
	
	public ImageShapeInterface getHead(){
		return head;
	}
	
	public AngleInterface getArms(){
		return arms;
	}
	
	public LineShapeInterface getBody(){
		return body;
	}
	
	public AngleInterface getLegs(){
		return legs;
	}
	
	public StringShapeInterface getText(){
		return text;
	}
	
//	public void setText(String newText){
//		text.setText(newText);
//	}
	
	public void setText(StringShapeInterface newText){
		text = newText;
	}
	
	@Tags({"move"})
	public void moveAvatar(int initX, int initY){
		int headStartX = head.getX();
		int headStartY = head.getY();
		int bodyStartX = body.getX();
		int bodyStartY = body.getY();
		int textStartX = text.getX();
		int textStartY = text.getY();
		
		head.setX(headStartX + initX);
		head.setY(headStartY + initY);
		arms.moveAngle(initX, initY);
		body.setX(bodyStartX + initX);
		body.setY(bodyStartY + initY);
		legs.moveAngle(initX, initY);
		text.setX(textStartX + initX);
		text.setY(textStartY + initY);
		
	}
	
	public void changeScale(int newScale){
		scale = newScale;
		
		arms.getLeftLine().setWidth(-1*scale*LINE_LENGTH);
		arms.getLeftLine().setHeight(scale*LINE_LENGTH);
		arms.getRightLine().setWidth(scale*LINE_LENGTH);
		arms.getRightLine().setHeight(scale*LINE_LENGTH);
		
		legs.getLeftLine().setWidth(-1*scale*LINE_LENGTH);
		legs.getLeftLine().setHeight(scale*LINE_LENGTH);
		legs.getRightLine().setWidth(scale*LINE_LENGTH);
		legs.getRightLine().setHeight(scale*LINE_LENGTH);
		legs.moveAngle(0, (2*scale*LINE_LENGTH-2*LINE_LENGTH));
		
		body.setHeight(2*scale*LINE_LENGTH);
	}
}
