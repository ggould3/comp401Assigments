package mp.interpreter;

import grail.tokens.TokenInterface;
import mp.table.TableInterface;

public interface InterpreterInterface {

	void setCommand(String command);
	Object getCommand();
	TableInterface getTable();
	Runnable createMove(TokenInterface[] tokenArray);
	Runnable createSay(TokenInterface[] tokenArray);
	void animateArthur();
	void animateLancelot();
	void animateGalahad();
	void animateRobin();
}
