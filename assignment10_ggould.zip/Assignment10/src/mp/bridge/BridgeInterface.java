package mp.bridge;

import util.models.PropertyListenerRegisterer;
import grail.graphics.*;

public interface BridgeInterface extends PropertyListenerRegisterer{

	AvatarInterface getArthur();
	AvatarInterface getLancelot();
	AvatarInterface getGalahad();
	AvatarInterface getRobin();
	AvatarInterface getGuard();
	GorgeInterface getGorge();
	OvalShapeInterface getKnightArea();
	OvalShapeInterface getGuardArea();
	boolean getOccupied();
	void approachBridge(AvatarInterface avatar);
	void sayString(String text);
	void passed();
	void failed();
	boolean preApproach();
	boolean preSay();
	boolean prePassed();
	boolean preFailed();
	
}
