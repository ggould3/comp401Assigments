package mp.controller;

import grail.graphics.AvatarInterface;

import java.awt.Component;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

import mp.bridge.BridgeInterface;
import util.annotations.Tags;

@Tags({"BridgeSceneController"})
public class BridgeSceneController implements BridgeControllerInterface{

	int lastClickX, lastClickY;
	//Keep track of original position
	int arthurX, arthurY, lancelotX, lancelotY, galahadX, galahadY, robinX, robinY, guardX, guardY;
	char charTyped;
	BridgeInterface scene;
	
	public BridgeSceneController(BridgeInterface theScene, Component view){
		scene = theScene;
		view.addMouseListener(this);
		view.addKeyListener(this);
		arthurX = scene.getArthur().getHead().getX();
		arthurY = scene.getArthur().getHead().getY();
		lancelotX = scene.getLancelot().getHead().getX();
		lancelotY = scene.getLancelot().getHead().getY();
		galahadX = scene.getGalahad().getHead().getX();
		galahadY = scene.getGalahad().getHead().getY();
		robinX = scene.getRobin().getHead().getX();
		robinY = scene.getRobin().getHead().getY();
		guardX = scene.getGuard().getHead().getX();
		guardY = scene.getGuard().getHead().getY();
	}
	
	public BridgeSceneController(BridgeInterface theScene){
		scene = theScene;
		arthurX = scene.getArthur().getHead().getX();
		arthurY = scene.getArthur().getHead().getY();
		lancelotX = scene.getLancelot().getHead().getX();
		lancelotY = scene.getLancelot().getHead().getY();
		galahadX = scene.getGalahad().getHead().getX();
		galahadY = scene.getGalahad().getHead().getY();
		robinX = scene.getRobin().getHead().getX();
		robinY = scene.getRobin().getHead().getY();
		guardX = scene.getGuard().getHead().getX();
		guardY = scene.getGuard().getHead().getY();
	}
	
	public void mouseClicked(MouseEvent e) {
		lastClickX = e.getX();
		lastClickY = e.getY();
	}

	public void keyTyped(KeyEvent e) {
		charTyped = e.getKeyChar();
		keyAction(charTyped);
	}
	
	private void keyAction(char key){
		switch(key){
		case 'a':
			move(scene.getArthur());
			break;
		case 'l':
			move(scene.getLancelot());
			break;
		case 'g':
			move(scene.getGalahad());
			break;
		case 'r':
			move(scene.getRobin());
			break;
		case 'o':
			moveBack();
			break;
		default:
			break;
		}
	}
	
	private void move(AvatarInterface avatar){
		int moveX = lastClickX - avatar.getHead().getX();
		int moveY = lastClickY - avatar.getHead().getY();
		avatar.moveAvatar(moveX, moveY);
	}
	
	private void moveBack(){
		scene.getArthur().moveAvatar(arthurX - scene.getArthur().getHead().getX(), arthurY - scene.getArthur().getHead().getY());
		scene.getLancelot().moveAvatar(lancelotX - scene.getLancelot().getHead().getX(), lancelotY - scene.getLancelot().getHead().getY());
		scene.getGalahad().moveAvatar(galahadX - scene.getGalahad().getHead().getX(), galahadY - scene.getGalahad().getHead().getY());
		scene.getRobin().moveAvatar(robinX - scene.getRobin().getHead().getX(), robinY - scene.getRobin().getHead().getY());
	}
	
	public void mousePressed(MouseEvent e) {}

	public void mouseReleased(MouseEvent e) {}

	public void mouseEntered(MouseEvent e) {}

	public void mouseExited(MouseEvent e) {}

	public void keyPressed(KeyEvent e) {}

	public void keyReleased(KeyEvent e) {}

}
