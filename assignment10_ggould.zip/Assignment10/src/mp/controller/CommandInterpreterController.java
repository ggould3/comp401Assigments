package mp.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JTextField;

import mp.interpreter.InterpreterInterface;
import util.annotations.PropertyNames;
import util.annotations.Tags;

@PropertyNames({"TextField", "Button", "MenuItem"})

@Tags({"CommandInterpreterController"})
public class CommandInterpreterController implements ActionListener{

	InterpreterInterface interpreter;
	JTextField textField = new JTextField();
	JButton button = new JButton();
	JMenuItem menuItem = new JMenuItem();
	
	public CommandInterpreterController(InterpreterInterface anInterpreter){
		interpreter = anInterpreter;
	}
	
	public CommandInterpreterController(InterpreterInterface anInterpreter, JTextField aTextField){
		interpreter = anInterpreter;
		textField = aTextField;
		textField.addActionListener(this);
	}
	
	public CommandInterpreterController(InterpreterInterface anInterpreter, JTextField aTextField, JButton aButton, JMenuItem aMenuItem){
		interpreter = anInterpreter;
		textField = aTextField;
		button = aButton;
		menuItem = aMenuItem;
		textField.addActionListener(this);
		button.addActionListener(this);
		menuItem.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e) {
		Object component = e.getSource();
		
		if(component == textField){
			String command = textField.getText();
			interpreter.setCommand(command);
		}else if(component == button){
			interpreter.setCommand("move Arthur 10 0");
			interpreter.setCommand("move Lancelot 10 0");
			interpreter.setCommand("move Galahad 10 0");
			interpreter.setCommand("move Robin 10 0");
		}else if(component == menuItem){
			interpreter.setCommand("move Arthur 0 10");
			interpreter.setCommand("move Lancelot 0 10");
			interpreter.setCommand("move Galahad 0 10");
			interpreter.setCommand("move Robin 0 10");
		}
	}
	
	public JTextField getTextField(){
		return textField;
	}
	
	public JButton getButton(){
		return button;
	}
	
	public JMenuItem getMenuItem(){
		return menuItem;
	}
	
}
