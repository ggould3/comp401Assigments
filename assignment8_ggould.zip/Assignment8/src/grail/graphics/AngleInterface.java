package grail.graphics;

public interface AngleInterface {

	LineShapeInterface getRightLine();
	LineShapeInterface getLeftLine();
	void moveAngle(int x, int y);
}
