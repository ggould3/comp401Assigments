package grail.graphics;

import util.annotations.Tags;
import util.models.PropertyListenerRegisterer;

@Tags({"Locatable"})
public interface LocatableInterface extends PropertyListenerRegisterer{

	int getX();
	int getY();
	void setX(int newX);
	void setY(int newY);
}
