package grail.graphics;

import util.annotations.Tags;

@Tags({"BoundedShape"})
public interface BoundedShapeInterface extends LocatableInterface{

	void setWidth(int newWidth);
	void setHeight(int newHeight);
	int getWidth();
	int getHeight();
}
