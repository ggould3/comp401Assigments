package grail.tokens;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@Tags({"Minus"})
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Input"})
@EditablePropertyNames({"Input"})

public class MinusToken implements TokenInterface{

	static String minusToken;
	
	//Constructor 1
	public MinusToken(){
		minusToken = "";
	}
	
	//Constructor 2
	public MinusToken(String mInput){
		minusToken = mInput;
	}
	
	//Setter
	public void setInput(String mInput){
		minusToken = mInput;
	}
	
	//Getter for token
	public String getInput(){
		return minusToken;
	}
}
