package mp.changeList;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;

public class ChangeList implements ChangeListInterface{

	ArrayList<PropertyChangeListener> changes;
	
	public ChangeList(){
		changes = new ArrayList<>();
	}
	
	public void notifyAllListeners(PropertyChangeEvent event){
		for (int i=0; i<changes.size(); i++){
			changes.get(i).propertyChange(event);
		}
	}
	
	public int size(){
		return changes.size();
	}
	
	public void add(PropertyChangeListener propChange){
		changes.add(propChange);
	}
	
	public void remove(PropertyChangeListener propChange){
		changes.remove(propChange);
	}
	
	public void remove(int index){
		changes.remove(index);
	}
	
	public int indexOf(PropertyChangeListener propChange){
		return changes.indexOf(propChange);
	}
	
	public boolean isListening(PropertyChangeListener propChange){
		return changes.contains(propChange);
	}
}
