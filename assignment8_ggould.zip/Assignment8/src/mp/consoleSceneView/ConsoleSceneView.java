package mp.consoleSceneView;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import util.annotations.Tags;
import mp.bridge.BridgeInterface;

@Tags({"ConsoleSceneView"})
public class ConsoleSceneView implements PropertyChangeListener{

	public ConsoleSceneView(BridgeInterface scene){
		scene.getArthur().getHead().addPropertyChangeListener(this);
			scene.getArthur().getArms().getLeftLine().addPropertyChangeListener(this);
			scene.getArthur().getArms().getRightLine().addPropertyChangeListener(this);
			scene.getArthur().getBody().addPropertyChangeListener(this);
			scene.getArthur().getLegs().getLeftLine().addPropertyChangeListener(this);
			scene.getArthur().getLegs().getRightLine().addPropertyChangeListener(this);
			scene.getArthur().getText().addPropertyChangeListener(this);
		scene.getGalahad().getHead().addPropertyChangeListener(this);
			scene.getGalahad().getArms().getLeftLine().addPropertyChangeListener(this);
			scene.getGalahad().getArms().getRightLine().addPropertyChangeListener(this);
			scene.getGalahad().getBody().addPropertyChangeListener(this);
			scene.getGalahad().getLegs().getLeftLine().addPropertyChangeListener(this);
			scene.getGalahad().getLegs().getRightLine().addPropertyChangeListener(this);
			scene.getGalahad().getText().addPropertyChangeListener(this);
		scene.getGuard().getHead().addPropertyChangeListener(this);
			scene.getGuard().getArms().getLeftLine().addPropertyChangeListener(this);
			scene.getGuard().getArms().getRightLine().addPropertyChangeListener(this);
			scene.getGuard().getBody().addPropertyChangeListener(this);
			scene.getGuard().getLegs().getLeftLine().addPropertyChangeListener(this);
			scene.getGuard().getLegs().getRightLine().addPropertyChangeListener(this);
			scene.getGuard().getText().addPropertyChangeListener(this);
		scene.getLancelot().getHead().addPropertyChangeListener(this);
			scene.getLancelot().getArms().getLeftLine().addPropertyChangeListener(this);
			scene.getLancelot().getArms().getRightLine().addPropertyChangeListener(this);
			scene.getLancelot().getBody().addPropertyChangeListener(this);
			scene.getLancelot().getLegs().getLeftLine().addPropertyChangeListener(this);
			scene.getLancelot().getLegs().getRightLine().addPropertyChangeListener(this);
			scene.getLancelot().getText().addPropertyChangeListener(this);
		scene.getRobin().getHead().addPropertyChangeListener(this);
			scene.getRobin().getArms().getLeftLine().addPropertyChangeListener(this);
			scene.getRobin().getArms().getRightLine().addPropertyChangeListener(this);
			scene.getRobin().getBody().addPropertyChangeListener(this);
			scene.getRobin().getLegs().getLeftLine().addPropertyChangeListener(this);
			scene.getRobin().getLegs().getRightLine().addPropertyChangeListener(this);
			scene.getRobin().getText().addPropertyChangeListener(this);
	}
	
	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		System.out.println("Property Change Event: " + evt);
		
	}

}
