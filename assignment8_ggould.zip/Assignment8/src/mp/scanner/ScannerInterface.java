package mp.scanner;

import grail.tokens.TokenInterface;

public interface ScannerInterface {
	void setScannedString(String newInput);
	String getScannedString();
	
	TokenInterface[] getTokens();
}
