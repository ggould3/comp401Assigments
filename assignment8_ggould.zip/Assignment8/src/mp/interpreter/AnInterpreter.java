package mp.interpreter;

import grail.graphics.AvatarInterface;
import grail.tokens.CommandMove;
import grail.tokens.CommandSay;
import grail.tokens.NumberInterface;
import grail.tokens.QuoteInterface;
import grail.tokens.TokenInterface;
import grail.tokens.WordInterface;
import grail.tokens.WordToken;
import mp.bridge.BridgeInterface;
import mp.scanner.ScannerInterface;
import mp.table.ATable;
import mp.table.TableInterface;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePatternNames;
import util.annotations.StructurePattern;
import util.annotations.Tags;
import util.annotations.Visible;

@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Command", "Table"})
@EditablePropertyNames({"Command"})
@Tags({"CommandInterpreter"})
public class AnInterpreter implements InterpreterInterface{

	ScannerInterface scanner;
	BridgeInterface bridge;
	String command = "";
	TokenInterface[] tokens = {new WordToken()};
	TableInterface table;
	
	public AnInterpreter(BridgeInterface initBridge, ScannerInterface initScanner){
		bridge = initBridge;
		scanner = initScanner;
		table = new ATable();
		fillTable(bridge);
	}
	
	public void setCommand(String newCommand){
		command = newCommand;
		scanner.setScannedString(command);
		tokens = scanner.getTokens();
		parseTokens(tokens);
	}
	
	public String getCommand(){
		return command;
	}
	
	private void parseTokens(TokenInterface[] tokenArray){
		//int length = tokenArray.length;
		
		if(tokenArray[0] instanceof CommandSay){
			QuoteInterface quoteToken = (QuoteInterface) tokenArray[1];
			String quote = quoteToken.getValue();
			bridge.sayString(quote);
		}else if(tokenArray[0] instanceof CommandMove){
			WordInterface avatarWord = (WordInterface) tokenArray[1];
			NumberInterface moveXNumber = (NumberInterface) tokenArray[2];
			NumberInterface moveYNumber = (NumberInterface) tokenArray[3];
			
			String avatarKey = avatarWord.getValue();
			AvatarInterface avatar = (AvatarInterface) table.get(avatarKey);
			
			int moveX = moveXNumber.getValue();
			int moveY = moveYNumber.getValue();
			
			avatar.moveAvatar(moveX, moveY);
		}else{
			System.out.println("Invalid command syntax, begin with \"say\" or \"move\"");
		}
	}
	
	private void fillTable(BridgeInterface initBridge){
		table.put("arthur", (Object) initBridge.getArthur());
		table.put("lancelot", (Object) initBridge.getLancelot());
		table.put("galahad", (Object) initBridge.getGalahad());
		table.put("robin", (Object) initBridge.getRobin());
		table.put("guard", (Object) initBridge.getGuard());
	}
	
	@Visible(false)
	public TableInterface getTable(){
		return table;
	}
}
