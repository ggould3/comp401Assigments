package mp.interpreter;

import mp.table.TableInterface;

public interface InterpreterInterface {

	void setCommand(String command);
	Object getCommand();
	TableInterface getTable();
}
