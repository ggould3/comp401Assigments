package grail.tokens;

public interface TokenInterface {
	void setInput(String newInput);
	String getInput();
}
