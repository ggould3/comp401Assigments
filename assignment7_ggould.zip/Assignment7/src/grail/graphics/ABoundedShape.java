package grail.graphics;

import util.annotations.Tags;

@Tags({"BoundedShape"})
public class ABoundedShape extends ALocatable implements BoundedShapeInterface{

	int width, height;
	
	public void setWidth(int newWidth){
		width = newWidth;
	}
	
	public void setHeight(int newHeight){
		height = newHeight;
	}
	
	public int getWidth(){
		return width;
	}
	
	public int getHeight(){
		return height;
	}
}
