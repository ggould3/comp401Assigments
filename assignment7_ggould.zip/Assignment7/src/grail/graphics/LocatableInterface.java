package grail.graphics;

import util.annotations.Tags;

@Tags({"Locatable"})
public interface LocatableInterface {

	int getX();
	int getY();
	void setX(int newX);
	void setY(int newY);
}
