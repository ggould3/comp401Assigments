package grail.graphics;

import util.annotations.Tags;

@Tags({"Locatable"})
public class ALocatable implements LocatableInterface{

	int x, y;
	
	public void setX(int newX){
		x = newX;
	}
	
	public void setY(int newY){
		y = newY;
	}
	
	public int getX(){
		return x;
	}
	
	public int getY(){
		return y;
	}
}
