package grail.graphics;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.misc.ThreadSupport;

//import javax.swing.Icon;
import javax.swing.ImageIcon;

@StructurePattern(StructurePatternNames.IMAGE_PATTERN)
@PropertyNames({"X", "Y", "ImageFileName", "Height", "Width"})
@EditablePropertyNames({"X", "Y", "ImageFileName", "Height", "Width"})

public class HeadObject extends ABoundedShape implements ImageShapeInterface{

	String imageFileName;
    
    public HeadObject(){
    	x = 0;
    	y = 0;
    	imageFileName = "";
    	height = 0;
    	width = 0;
    }
    
    public HeadObject (String image, int initX, int initY) {	
    	
    	imageFileName = image;
    	ImageIcon icon = new ImageIcon("src/"+imageFileName);
    	ThreadSupport.sleep(3000);
    	height = icon.getIconHeight();
    	width = icon.getIconWidth();
    	x = initX;
    	y = initY;      
    }   
	
	public String getImageFileName() {
		return imageFileName;
	}
	
	public void setImageFileName(String newVal) {
		imageFileName = newVal;
	}   
}
