package grail.graphics;

public interface OvalShapeInterface extends BoundedShapeInterface{

}
