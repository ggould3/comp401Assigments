package main;

import util.misc.ThreadSupport;
import bus.uigen.OEFrame;
import bus.uigen.ObjectEditor;
import mp.bridge.*;
import mp.interpreter.AnInterpreter;
import mp.interpreter.InterpreterInterface;
import mp.scanner.*;
import mp.table.ATable;
//import mp.scanner.*;
//import grail.graphics.*;
import mp.table.TableInterface;


public class Assignment7 {

	final static int WINDOW_X = 1100;
	final static int WINDOW_Y = 700;
	final static int LOCATION_X_Y = 0;
	final static int SLEEP = 2000;
	final static int SCANNER_X = 400;
	
	public static void main(String[] args) {
		ScannerInterface scanner = new ScannerBean();
		BridgeInterface bridge = new BridgeScene();
		InterpreterInterface interpreter = new AnInterpreter(bridge, scanner);
		
		//Set location for bridge window, approach, then stop
		OEFrame bridgeEditor = ObjectEditor.edit(bridge);
		bridgeEditor.setSize(WINDOW_X, WINDOW_Y);
		bridgeEditor.setLocation(LOCATION_X_Y, LOCATION_X_Y);
		bridgeEditor.refresh();
		ThreadSupport.sleep(SLEEP);
		bridge.approachBridge(bridge.getRobin());
		bridgeEditor.refresh();
		System.out.println("The animation will continue in 4 seconds, resize the window if necessary");
		ThreadSupport.sleep(2*SLEEP);
		
		//Set location of interpreter and scanner
		OEFrame scannerEditor = ObjectEditor.edit(scanner);
		OEFrame interEditor = ObjectEditor.edit(interpreter);
		scannerEditor.setLocation(SCANNER_X, LOCATION_X_Y);
		interEditor.setLocation(LOCATION_X_Y, LOCATION_X_Y);
		
		interpreter.setCommand("SaY \"I am the interpreter!\"");
		interEditor.refresh();
		scannerEditor.refresh();
		bridgeEditor.refresh();
		ThreadSupport.sleep(2*SLEEP);
		interpreter.setCommand("SaY \"As am I!\"");
		interEditor.refresh();
		scannerEditor.refresh();
		bridgeEditor.refresh();
		ThreadSupport.sleep(2*SLEEP);
		interpreter.setCommand("movE LanCelOT 75 300");
		interEditor.refresh();
		scannerEditor.refresh();
		bridgeEditor.refresh();
		ThreadSupport.sleep(2*SLEEP);
		
		System.out.println("****TABLE DEMONSTRATION****");
		TableInterface demoTable = new ATable();
		String fish = "fish";
		String lion = "lion";
		String bear = "bear";
		String lemur = "lemur";
		String[] order = {"first", "second", "third", "fourth"};
		
		System.out.println("******Original Table******");
		demoTable.put(order[0], fish);
		demoTable.put(order[1], lion);
		demoTable.put(order[2], bear);
		demoTable.put(order[3], lemur);
		for (int i=0; i<order.length; i++){
			System.out.println("Key: " + order[i] + ", Value: " + demoTable.get(order[i]));
		}
		
		System.out.println("******Replaced Table******");
		String barracuda = "barracuda";
		String unicorn = "unicorn";
		demoTable.put(order[1], barracuda);
		demoTable.put(order[3], unicorn);
		for (int i=0; i<order.length; i++){
			System.out.println("Key: " + order[i] + ", Value: " + demoTable.get(order[i]));
		}
		System.out.println("****End of Table Demonstration****");
	}
}
