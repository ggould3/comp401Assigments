package grail.graphics;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;

@StructurePattern(StructurePatternNames.OVAL_PATTERN)
@PropertyNames({"X", "Y", "Width", "Height"})
@EditablePropertyNames({"X", "Y", "Width", "Height"})

public class OvalObject implements OvalShapeInterface{

	int x, y, width, height;
	
	public OvalObject(){
		x = 0;
		y = 0;
		width = 0;
		height = 0;
	}
	
	public OvalObject(int initX, int initY, int initWidth, int initHeight){
		x = initX;
		y = initY;
		width = initWidth;
		height = initHeight;
	}
	
	public int getX(){
		return x;
	}
	
	public void setX(int newX){
		x = newX;
	}
	
	public int getY(){
		return y;
	}
	
	public void setY(int newY){
		y = newY;
	}
	
	public int getWidth(){
		return width;
	}
	
	public void setWidth(int newWidth){
		width = newWidth;
	}
	
	public int getHeight(){
		return height;
	}
	
	public void setHeight(int newHeight){
		height = newHeight;
	}
}
