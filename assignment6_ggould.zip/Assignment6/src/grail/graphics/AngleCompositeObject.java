package grail.graphics;

//import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"LeftLine", "RightLine"})
//@EditablePropertyNames({})

@Tags({"Angle"})
public class AngleCompositeObject implements AngleInterface{

	LineShapeInterface leftLine = new LineObject();
	LineShapeInterface rightLine = new LineObject();
	
	public AngleCompositeObject(){
		leftLine.setX(0);
		leftLine.setY(0);
		leftLine.setWidth(-10);
		leftLine.setHeight(10);
		
		rightLine.setX(0);
		rightLine.setY(0);
		rightLine.setWidth(10);
		rightLine.setHeight(10);
	}
	
	public AngleCompositeObject(int X, int Y, int Width1, int Height1, int Width2, int Height2){
		leftLine.setX(X);
		leftLine.setY(Y);
		leftLine.setWidth(Width1);
		leftLine.setHeight(Height1);
		
		rightLine.setX(X);
		rightLine.setY(Y);
		rightLine.setWidth(Width2);
		rightLine.setHeight(Height2);
	}
	
	public LineShapeInterface getLeftLine(){
		return leftLine;
	}
	
	public LineShapeInterface getRightLine(){
		return rightLine;
	}
	
	@Tags({"move"})
	public void moveAngle(int initX, int initY){
		int leftStartX = leftLine.getX();
		int leftStartY = leftLine.getY();
		int rightStartX = rightLine.getX();
		int rightStartY = rightLine.getY();
		
		leftLine.setX(leftStartX + initX);
		leftLine.setY(leftStartY + initY);
		rightLine.setX(rightStartX + initX);
		rightLine.setY(rightStartY + initY);
	}
}
