package grail.graphics;

public interface ImageShapeInterface {
	
	int getX();
	int getY();
	String getImageFileName();
	int getHeight();
	int getWidth();
	
	void setX(int X);
	void setY(int Y);
	void setImageFileName(String Image);

}
