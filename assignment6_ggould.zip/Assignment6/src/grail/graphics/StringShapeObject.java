package grail.graphics;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;

@StructurePattern(StructurePatternNames.STRING_PATTERN)
@PropertyNames({"X", "Y", "Text"})
@EditablePropertyNames({"X", "Y", "Text"})

public class StringShapeObject implements StringShapeInterface{

	String text;
	int x, y;

	public StringShapeObject(){
		text = "";
		x = 0;
		y = 0;
	}
	
	public StringShapeObject(String inputText, int X, int Y) {
		text = inputText;
		x = X;
		y = Y;
	}
	
	public int getX() {
		return x;
	}
	public void setX(int newX) {
		x = newX;
	}
	public int getY() {
		return y;
	}
	public void setY(int newY) {
		y = newY;
	}
	public String getText() {
		return text;
	}
	public void setText(String newVal) {
		text = newVal;
	}
	
}
