package grail.graphics;

public interface LineShapeInterface {

	int getX();
	int getY();
	int getWidth();
	int getHeight();
	
	void setX(int X);
	void setY(int Y);
	void setWidth(int Width);
	void setHeight(int Height);
}
