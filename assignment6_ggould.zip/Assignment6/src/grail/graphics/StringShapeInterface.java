package grail.graphics;

public interface StringShapeInterface {

	int getX();
	int getY();
	String getText();
	
	void setX(int X);
	void setY(int Y);
	void setText(String Text);
}
