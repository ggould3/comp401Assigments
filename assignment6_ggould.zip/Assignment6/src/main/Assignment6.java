package main;

import util.misc.ThreadSupport;
import bus.uigen.OEFrame;
import bus.uigen.ObjectEditor;
import mp.bridge.*;
import mp.scanner.*;
//import mp.scanner.*;
//import grail.graphics.*;


public class Assignment6 {

	public static void main(String[] args) {
		ScannerInterface scanner = new ScannerBean();
		BridgeInterface bridge = new BridgeScene();
		
		OEFrame edit = ObjectEditor.edit(scanner);
		scanner.setScannedString("approach \"bridge\" {34} move -45 + 09 CaLL");
		edit.setSize(400, 400);
		edit.refresh();
		System.out.println("The animation will begin in 8 seconds...");
		ThreadSupport.sleep(8000);
		
		OEFrame editor = ObjectEditor.edit(bridge);
		editor.setSize(1100, 700);
		editor.setLocation(0,0);
		editor.refresh();
		ThreadSupport.sleep(2000);
		
		bridge.approachBridge(bridge.getRobin());
		editor.refresh();
		ThreadSupport.sleep(2000);
		bridge.sayString("What is your favorite color?");
		editor.refresh();
		ThreadSupport.sleep(2000);
		bridge.sayString("African Swallow");
		editor.refresh();
		ThreadSupport.sleep(2000);
		bridge.failed();
		editor.refresh();
		
		ThreadSupport.sleep(2000);
		bridge.approachBridge(bridge.getArthur());
		editor.refresh();
		ThreadSupport.sleep(1000);
		bridge.sayString("Can you even name a color?");
		editor.refresh();
		ThreadSupport.sleep(2000);
		bridge.sayString("Green");
		editor.refresh();
		ThreadSupport.sleep(2000);
		bridge.sayString("Oh, well...");
		editor.refresh();
		ThreadSupport.sleep(1000);
		bridge.failed();
		editor.refresh();
		ThreadSupport.sleep(1000);
		bridge.passed();
		editor.refresh();
	}
}
