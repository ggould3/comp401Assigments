package mp.scanner;

public interface ScannerInterface {
	void setScannedString(String newInput);
	String getScannedString();
	
	Object[] getTokens();
}
