package main;

import util.misc.ThreadSupport;
import bus.uigen.OEFrame;
import bus.uigen.ObjectEditor;
import mp.bridge.BridgeScene;
//import mp.scanner.*;
//import grail.graphics.*;


public class Assignment5 {

	public static void main(String[] args) {
		BridgeScene bridge = new BridgeScene();
		
		OEFrame editor = ObjectEditor.edit(bridge);
		editor.setSize(1000, 700);
		editor.refresh();
		ThreadSupport.sleep(2000);
		
		for(int i = 0; i<100; i++){
		bridge.getGuard().moveAvatar(2, 1);
		editor.refresh();
		ThreadSupport.sleep(20);
		}
		
		ThreadSupport.sleep(500);
		bridge.getGuard().changeScale(2);
		editor.refresh();
	}
}
