package mp.bridge;

import grail.graphics.*;

public interface BridgeInterface {

	AvatarInterface getArthur();
	AvatarInterface getLancelot();
	AvatarInterface getGalahad();
	AvatarInterface getRobin();
	AvatarInterface getGuard();
}
