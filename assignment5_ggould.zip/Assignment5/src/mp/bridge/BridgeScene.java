package mp.bridge;

import grail.graphics.*;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Arthur", "Lancelot", "Galahad", "Robin", "Guard"})

@Tags({"BridgeScene"})
public class BridgeScene implements BridgeInterface{

	AvatarInterface arthur;
	AvatarInterface lancelot;
	AvatarInterface galahad;
	AvatarInterface robin;
	AvatarInterface guard;
	
	public BridgeScene(){
		arthur = new AvatarCompositeObject("arthur.jpg", 40, 20);
		lancelot = new AvatarCompositeObject("lancelot.jpg", 190, 20);
		galahad = new AvatarCompositeObject("galahad.jpg", 340, 20);
		robin = new AvatarCompositeObject("robin.jpg", 115, 220);
		guard = new AvatarCompositeObject("guard.jpg", 265, 220);
	}
	
	
	public AvatarInterface getArthur(){
		return arthur;
	}
	
	public AvatarInterface getLancelot(){
		return lancelot;
	}
	
	public AvatarInterface getGalahad(){
		return galahad;
	}
	
	public AvatarInterface getRobin(){
		return robin;
	}
	
	public AvatarInterface getGuard(){
		return guard;
	}

}
