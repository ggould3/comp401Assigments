package grail.graphics;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;

@StructurePattern(StructurePatternNames.LINE_PATTERN)
@PropertyNames({"X", "Y", "Width", "Height"})
@EditablePropertyNames({"X", "Y", "Width", "Height"})

public class LineObject implements LineShapeInterface{

	int x, y, width, height;
	
	public LineObject(){
		x = 0;
		y = 0;
		width = 10;
		height = 10;
	}
	
	public LineObject (int X, int Y, int Width, int Height) {
		x = X; 
		y = Y;
		width = Width;
		height = Height;	
	}
	
	public int getX() {
		return x;
	}
	
	public void setX(int newX) {
		x = newX;
	}
	
	public int getY() { 
		return y; 
	}
	
	public void setY(int newY) {
		y = newY;
	}
	
	public int getWidth() {
		return width;
	}
	
	public void setWidth(int newVal) {
		width = newVal;
	}
	
	public int getHeight() {
		return height;
	}
	
	public void setHeight(int newHeight) {
		height = newHeight;
	}
	
}
