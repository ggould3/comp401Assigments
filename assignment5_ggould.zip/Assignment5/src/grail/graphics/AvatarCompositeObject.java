package grail.graphics;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Head", "Arms", "Body", "Legs", "Text"})
@EditablePropertyNames({"Text"})

@Tags({"Avatar"})
public class AvatarCompositeObject implements AvatarInterface{

	ImageShapeInterface head;
	AngleInterface arms;
	LineShapeInterface body;
	AngleInterface legs;
	StringShapeInterface text;
	
	int scale = 1;
	int lineLength = 40;
	
	public AvatarCompositeObject(String HeadFileName){
		head = new HeadObject(HeadFileName, 40, 20);
			int headWidth = head.getWidth();
			int headHeight = head.getHeight();
		arms = new AngleCompositeObject((headWidth/2+40), headHeight+20, lineLength, lineLength, -1*lineLength, lineLength);
		body = new LineObject((headWidth/2+40), headHeight+20, 0, 2*lineLength);
		legs = new AngleCompositeObject((headWidth/2)+40, (headHeight+100), lineLength, lineLength, -1*lineLength, lineLength);
		text = new StringShapeObject("Hello There!", headWidth+40, 20);
	}
	
	public AvatarCompositeObject(String HeadFileName, int initX, int initY){
		head = new HeadObject(HeadFileName, initX, initY);
			int headWidth = head.getWidth();
			int headHeight = head.getHeight();
		arms = new AngleCompositeObject((headWidth/2+initX), headHeight+initY, lineLength, lineLength, -1*lineLength, lineLength);
		body = new LineObject((headWidth/2+initX), headHeight+initY, 0, 2*lineLength);
		legs = new AngleCompositeObject((headWidth/2)+initX, (headHeight+80+initY), lineLength, lineLength, -1*lineLength, lineLength);
		text = new StringShapeObject("Hello There!", headWidth+initX, initY);
	}
	
	public ImageShapeInterface getHead(){
		return head;
	}
	
	public AngleInterface getArms(){
		return arms;
	}
	
	public LineShapeInterface getBody(){
		return body;
	}
	
	public AngleInterface getLegs(){
		return legs;
	}
	
	public StringShapeInterface getText(){
		return text;
	}
	
//	public void setText(String newText){
//		text.setText(newText);
//	}
	
	public void setText(StringShapeInterface newText){
		text = newText;
	}
	
	@Tags({"move"})
	public void moveAvatar(int initX, int initY){
		int headStartX = head.getX();
		int headStartY = head.getY();
		int bodyStartX = body.getX();
		int bodyStartY = body.getY();
		int textStartX = text.getX();
		int textStartY = text.getY();
		
		head.setX(headStartX + initX);
		head.setY(headStartY + initY);
		arms.moveAngle(initX, initY);
		body.setX(bodyStartX + initX);
		body.setY(bodyStartY + initY);
		legs.moveAngle(initX, initY);
		text.setX(textStartX + initX);
		text.setY(textStartY + initY);
		
	}
	
	public void changeScale(int newScale){
		scale = newScale;
		
		arms.getLeftLine().setWidth(-1*scale*lineLength);
		arms.getLeftLine().setHeight(scale*lineLength);
		arms.getRightLine().setWidth(scale*lineLength);
		arms.getRightLine().setHeight(scale*lineLength);
		
		legs.getLeftLine().setWidth(-1*scale*lineLength);
		legs.getLeftLine().setHeight(scale*lineLength);
		legs.getRightLine().setWidth(scale*lineLength);
		legs.getRightLine().setHeight(scale*lineLength);
		legs.moveAngle(0, (2*scale*lineLength-2*lineLength));
		
		body.setHeight(2*scale*lineLength);
	}
}
