package grail.graphics;

public interface AvatarInterface {

	ImageShapeInterface getHead();
	AngleInterface getArms();
	LineShapeInterface getBody();
	AngleInterface getLegs();
	StringShapeInterface getText();
	void setText(StringShapeInterface newText);
//	void setText(String newtext);
	void moveAvatar(int initX, int initY);
	void changeScale(int newScale);
}
