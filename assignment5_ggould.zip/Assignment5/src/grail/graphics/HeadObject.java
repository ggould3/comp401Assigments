package grail.graphics;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.misc.ThreadSupport;

//import javax.swing.Icon;
import javax.swing.ImageIcon;

@StructurePattern(StructurePatternNames.IMAGE_PATTERN)
@PropertyNames({"X", "Y", "ImageFileName", "Height", "Width"})
@EditablePropertyNames({"X", "Y", "ImageFileName"})

public class HeadObject implements ImageShapeInterface{

	String imageFileName;
	int imageHeight;
	int imageWidth;
    int x, y;
    
    public HeadObject(){
    	x = 0;
    	y = 0;
    	imageFileName = "";
    	imageHeight = 0;
    	imageWidth = 0;
    }
    
    public HeadObject (String image, int initX, int initY) {	
    	
    	imageFileName = image;
    	ImageIcon icon = new ImageIcon("src/"+imageFileName);
    	ThreadSupport.sleep(3000);
    	imageHeight = icon.getIconHeight();
    	imageWidth = icon.getIconWidth();
    	x = initX;
    	y = initY;      
    }   
    
    public int getX() {
    	return x;
    }
    
	public void setX(int newX) {
		x = newX;
	}
	
	public int getY() { 
		return y; 
	}
	
	public void setY(int newY) {
		y = newY;
	}
	
	public String getImageFileName() {
		return imageFileName;
	}
	
	public void setImageFileName(String newVal) {
		imageFileName = newVal;
	}   
	
	public int getHeight(){
		return imageHeight;
	}
	
	public int getWidth(){
		return imageWidth;
	}
}
