package Main;

import java.util.Scanner;

public class Assignment2 {
	
	static String input;
	static Scanner keyboard = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Enter your command separated by spaces. Enter '.' to terminate.");
		
		while (true){
			//Assignment2.scanInput(); //Part 1
			
			ScannerBean scanString = new ScannerBean(); //Part 2
			scanString.setScannedString(keyboard.nextLine()); //Part 2
		}
	}
	
	//Part 1 Scanner
	//Scan input String
	@SuppressWarnings("unused") //Suppressed to check for checkstyles warnings
	private static void scanInput(){
		input = keyboard.nextLine();
		
		int index = 0;
		int subStart;
		int subEnd;
		
		while (index < input.length()){
			if (input.charAt(index) == '.'){
				System.out.println("Terminating program.");
				System.exit(0);
			}else if (Character.isDigit(input.charAt(index))){ //Grabs Numbers
				subStart = index;
				int nextChar = index + 1;
				System.out.print("number: ");
				
				if (index == (input.length()-1)){
					subEnd = nextChar;
					System.out.println(input.substring(subStart,subEnd));
					index = nextChar + 1;
					break;
				}
				
				while (nextChar < input.length()){
					if(Character.isDigit(input.charAt(nextChar)) && nextChar == (input.length()-1)){
						subEnd = nextChar+1;
						System.out.println(input.substring(subStart,subEnd));
						index = nextChar + 1;
						break;
					}else if (Character.isDigit(input.charAt(nextChar)) && nextChar < input.length()){
						nextChar++;
					}else{
						subEnd = nextChar;
						System.out.println(input.substring(subStart,subEnd));
						index = nextChar + 1;
						break;
					}
				}
			}else if(input.charAt(index)=='"'){ //Grabs Quotes
				subStart = index;
				int nextChar = index + 1;
				
				while (nextChar < input.length()){
					if (input.charAt(nextChar) == '"'){
						subEnd = nextChar;
						System.out.println("quoted string: "+input.substring(subStart+1,subEnd));
						index = nextChar + 1;
						break;
					}else if (nextChar == (input.length()-1) && !(input.charAt(nextChar) == '"')){
						System.out.println("Error: no closing quotation found.");
						System.exit(0);
					}else{
						nextChar++;
					}
				}
			}else if (Character.isLetter(input.charAt(index))){ //Grabs Words
				subStart = index;
				int nextChar = index + 1;
				System.out.print("word: ");
				
				if (index == (input.length()-1)){
					subEnd = nextChar;
					System.out.println(input.substring(subStart,subEnd));
					index = nextChar + 1;
					break;
				}
				
				while (nextChar < input.length()){
					if(Character.isLetter(input.charAt(nextChar)) && nextChar == (input.length()-1)){
						subEnd = nextChar+1;
						System.out.println(input.substring(subStart,subEnd));
						index = nextChar + 1;
						break;
					}else if (Character.isLetter(input.charAt(nextChar)) && nextChar < input.length()){
						nextChar++;
					}else{
						subEnd = nextChar;
						System.out.println(input.substring(subStart,subEnd));
						index = nextChar + 1;
						break;
					}
				}
			}else{
				index++;
			}
		}
	}
}
