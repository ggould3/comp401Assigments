package grail.graphics;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import mp.changeList.ChangeList;
import mp.changeList.ChangeListInterface;
import util.annotations.Tags;

@Tags({"Locatable"})
public abstract class ALocatable implements LocatableInterface{

	int x, y;
	ChangeListInterface changes = new ChangeList();
	
	public void setX(int newX){
		int oldX = getX();
		x = newX;
		changes.notifyAllListeners(new PropertyChangeEvent(this, "X", oldX, newX));
	}
	
	public void setY(int newY){
		int oldY = getY();
		y = newY;
		changes.notifyAllListeners(new PropertyChangeEvent(this, "Y", oldY, newY));
	}
	
	public int getX(){
		return x;
	}
	
	public int getY(){
		return y;
	}

	public void addPropertyChangeListener(PropertyChangeListener listener) {
		changes.add(listener);
		
	}
}
