package grail.graphics;

import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"LeftCliff", "RightCliff", "BridgeTop", "BridgeBottom"})

@Tags({"Gorge"})
public class GorgeCompositeObject implements GorgeInterface{

	LineShapeInterface leftCliff;
	LineShapeInterface rightCliff;
	LineShapeInterface bridgeTop;
	LineShapeInterface bridgeBottom;
	
	int gorgeLeft = 700;
	int gorgeRight = 900;
	
	public GorgeCompositeObject(){
		leftCliff = new LineObject(gorgeLeft, 0, 0, 700);
		rightCliff = new LineObject(gorgeRight, 0, 0, 700);
		bridgeTop = new LineObject(gorgeLeft, 400, gorgeRight-gorgeLeft, 0);
		bridgeBottom = new LineObject(gorgeLeft, 500, gorgeRight-gorgeLeft, 0);
	}
	
	public LineShapeInterface getLeftCliff(){
		return leftCliff;
	}
	
	public LineShapeInterface getRightCliff(){
		return rightCliff;
	}
	
	public LineShapeInterface getBridgeTop(){
		return bridgeTop;
	}
	
	public LineShapeInterface getBridgeBottom(){
		return bridgeBottom;
	}
}
