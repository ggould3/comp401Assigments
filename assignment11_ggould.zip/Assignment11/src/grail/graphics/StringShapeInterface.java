package grail.graphics;

public interface StringShapeInterface extends LocatableInterface{

	String getText();
	void setText(String Text);
}
