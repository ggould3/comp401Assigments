package grail.commands;

import util.annotations.Tags;
import mp.bridge.BridgeInterface;

@Tags({"SayCommand"})
public class SayCommand implements Runnable{

	BridgeInterface scene;
	String text;
	
	public SayCommand(BridgeInterface scene, String text){
		this.scene = scene;
		this.text = text;
	}
	
	public void run() {
		scene.sayString(text);
	}

}
