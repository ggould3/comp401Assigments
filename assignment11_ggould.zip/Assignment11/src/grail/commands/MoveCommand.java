package grail.commands;

import grail.graphics.AvatarInterface;
import util.annotations.Tags;

@Tags({"MoveCommand"})
public class MoveCommand implements Runnable{

	AvatarInterface avatar;
	int moveX, moveY;
	
	public MoveCommand(AvatarInterface avatar, int moveX, int moveY){
		this.avatar = avatar;
		this.moveX = moveX;
		this.moveY = moveY;
	}
	
	public void run() {
		avatar.moveAvatar(moveX, moveY);
	}

}
