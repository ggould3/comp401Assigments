package grail.commands;

import util.annotations.Tags;
import grail.graphics.AvatarInterface;
import mp.bridge.BridgeInterface;

@Tags({"ApproachCommand"})
public class ApproachCommand implements Runnable{
	
	BridgeInterface scene;
	AvatarInterface avatar;
	
	public ApproachCommand(BridgeInterface scene, AvatarInterface avatar){
		this.scene = scene;
		this.avatar = avatar;
	}
	
	public void run(){
		scene.approachBridge(avatar);
	}

}
