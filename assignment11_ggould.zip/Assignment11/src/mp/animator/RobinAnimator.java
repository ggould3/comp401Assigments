package mp.animator;

import grail.graphics.AvatarInterface;
import util.annotations.Tags;
import util.misc.ThreadSupport;

public abstract class RobinAnimator {

	final static int X_STEP = 2;
	final static int Y_STEP = 1;
	final static int SLEEP_STEP = 20;
	final static int SECOND_MILLIS = 1000;
	
	public RobinAnimator(){
		
	}
	
	public synchronized static void animateAvatar(AvatarInterface avatar){
		for(int i=0; i<50; i++){
			avatar.moveAvatar(X_STEP, Y_STEP);
			ThreadSupport.sleep(SLEEP_STEP);
		}
		
		avatar.moveAvatar(-(X_STEP*SECOND_MILLIS/SLEEP_STEP), -(Y_STEP*SECOND_MILLIS/SLEEP_STEP));
	}
}
