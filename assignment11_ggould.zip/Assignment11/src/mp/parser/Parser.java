package mp.parser;

import java.util.List;

import grail.commands.ApproachCommand;
import grail.commands.CommandList;
import grail.commands.FailCommand;
import grail.commands.MoveCommand;
import grail.commands.PassCommand;
import grail.commands.RepeatCommand;
import grail.commands.SayCommand;
import grail.graphics.AvatarCompositeObject;
import grail.graphics.AvatarInterface;
import grail.tokens.CommandApproach;
import grail.tokens.CommandFail;
import grail.tokens.CommandMove;
import grail.tokens.CommandPass;
import grail.tokens.CommandRepeat;
import grail.tokens.CommandSay;
import grail.tokens.NumberInterface;
import grail.tokens.NumberToken;
import grail.tokens.QuoteInterface;
import grail.tokens.StartToken;
import grail.tokens.TokenInterface;
import grail.tokens.WordInterface;
import mp.bridge.BridgeInterface;
import mp.scanner.ScannerBean;
import mp.scanner.ScannerInterface;
import mp.table.ATable;
import mp.table.TableInterface;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"CommandText", "CommandObject"})
@EditablePropertyNames({"CommandText"})
@Tags({"Parser"})
public class Parser implements ParserInterface{
	
	BridgeInterface scene;
	TableInterface table;
	ScannerInterface scanner;
	TokenInterface[] tokens;
	String commandText;
	public int marker = 0;
	Runnable parsedCommand;
	
	public Parser(BridgeInterface scene){
		this.scene = scene;
		table = new ATable();
		fillTable(scene);
		scanner = new ScannerBean();
	}
	
	public void setCommandText(String newCommand){
		marker = 0;
		commandText = newCommand;
		scanner.setScannedString(newCommand);
		tokens = scanner.getTokens();
		parsedCommand = parseCommand(tokens);
	}
	
	public String getCommandText(){
		return commandText;
	}
	
	public Runnable getCommandObject(){
		return parsedCommand;
	}
	
	@Tags({"parseCommand"})
	public Runnable parseCommand(TokenInterface[] tokenArray){
		if(marker >= tokenArray.length){
			return null;
		}
		
		if(tokenArray[marker] instanceof CommandSay){
			marker++;
			return createSay(tokenArray);
		}else if(tokenArray[marker] instanceof CommandMove){
			marker++;
			return createMove(tokenArray);
		}else if(tokenArray[marker] instanceof CommandApproach){
			marker++;
			return createApproach(tokenArray);
		}else if(tokenArray[marker] instanceof CommandPass){
			marker++;
			return createPass(tokenArray);
		}else if(tokenArray[marker] instanceof CommandFail){
			marker++;
			return createFail(tokenArray);
		}else if(tokenArray[marker] instanceof StartToken){
			marker++;
			return createCommandList(tokenArray);
		}else if(tokenArray[marker] instanceof CommandRepeat){
			marker++;
			return createRepeat(tokenArray);
		}else{
			System.out.println("Invalid command syntax");
		}
		
		return null;
	}
	
	@Tags({"parseMove"})
	public Runnable createMove(TokenInterface[] tokenArray){
		WordInterface avatarWord = (WordInterface) tokenArray[marker];
		NumberInterface moveXNumber = (NumberInterface) tokenArray[marker+1];
		NumberInterface moveYNumber = (NumberInterface) tokenArray[marker+2];
		
		String avatarKey = avatarWord.getValue();
		AvatarInterface avatar = (AvatarInterface) table.get(avatarKey);
		
		int moveX = moveXNumber.getValue();
		int moveY = moveYNumber.getValue();
		
		marker += 3;
		return new MoveCommand(avatar, moveX, moveY);
	}
	
	@Tags({"parseSay"})
	public Runnable createSay(TokenInterface[] tokenArray){
		QuoteInterface quoteToken = (QuoteInterface) tokenArray[marker];
		String quote = quoteToken.getValue();
		marker++;
		return new SayCommand(scene, quote);
	}
	
	@Tags({"parseApproach"})
	public Runnable createApproach(TokenInterface[] tokenArray){
		WordInterface avatarWord = (WordInterface) tokenArray[marker];
		String avatarKey = avatarWord.getValue();
		AvatarInterface avatar = (AvatarInterface) table.get(avatarKey);
		marker++;
		return new ApproachCommand(scene, avatar);
	}
	
	@Tags({"parsePass"})
	public Runnable createPass(TokenInterface[] tokenArray){
		return new PassCommand(scene);
	}
	
	@Tags({"parseFail"})
	public Runnable createFail(TokenInterface[] tokenArray){
		return new FailCommand(scene);
	}
	
	@Tags({"parseCommandList"})
	public Runnable createCommandList(TokenInterface[] tokenArray){
		Runnable list = new CommandList();
		Runnable nextCom = parseCommand(tokenArray);
		
		while(nextCom != null){
			((CommandList) list).add(nextCom);
			nextCom = parseCommand(tokenArray);
		}
		
		return list;
	}
	
	@Tags({"parseRepeat"})
	public Runnable createRepeat(TokenInterface[] tokenArray){
		int numRepeats = ((NumberToken) tokenArray[marker]).getValue();
		marker++;
		Runnable command = parseCommand(tokenArray);
		
		return new RepeatCommand(numRepeats, command);
	}
	
	private void fillTable(BridgeInterface initBridge){
		table.put("arthur", (Object) initBridge.getArthur());
		table.put("lancelot", (Object) initBridge.getLancelot());
		table.put("galahad", (Object) initBridge.getGalahad());
		table.put("robin", (Object) initBridge.getRobin());
		table.put("guard", (Object) initBridge.getGuard());
	}

}
