package mp.interpreter;

import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;

import util.models.PropertyListenerRegisterer;
import grail.tokens.TokenInterface;
import mp.table.TableInterface;

public interface InterpreterInterface extends PropertyListenerRegisterer{

	void setCommand(String command);
	Object getCommand();
	TableInterface getTable();
	void animateArthur();
	void animateLancelot();
	void animateGalahad();
	void animateRobin();
}
