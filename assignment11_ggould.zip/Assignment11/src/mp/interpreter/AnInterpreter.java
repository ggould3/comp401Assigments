package mp.interpreter;

import java.awt.event.ActionEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import grail.commands.AnimateCommand;
import grail.commands.MoveCommand;
import grail.commands.SayCommand;
import grail.graphics.AvatarInterface;
import grail.tokens.CommandMove;
import grail.tokens.CommandSay;
import grail.tokens.NumberInterface;
import grail.tokens.QuoteInterface;
import grail.tokens.TokenInterface;
import grail.tokens.WordInterface;
import grail.tokens.WordToken;
import mp.bridge.BridgeInterface;
import mp.changeList.ChangeList;
import mp.changeList.ChangeListInterface;
import mp.parser.Parser;
import mp.parser.ParserInterface;
import mp.scanner.ScannerInterface;
import mp.table.ATable;
import mp.table.TableInterface;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePatternNames;
import util.annotations.StructurePattern;
import util.annotations.Tags;
import util.annotations.Visible;

@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Command", "Table"})
@EditablePropertyNames({"Command"})
@Tags({"CommandInterpreter"})
public class AnInterpreter implements InterpreterInterface{

	ScannerInterface scanner;
	BridgeInterface bridge;
	String command = "";
	TokenInterface[] tokens = {new WordToken()};
	TableInterface table;
	final static String ANIMATE_THREAD_NAME = "Avatar animation thread";
	int threadNumber;
	ParserInterface parser;
	ChangeListInterface changes = new ChangeList();
	
	public AnInterpreter(BridgeInterface initBridge, ScannerInterface initScanner){
		bridge = initBridge;
		scanner = initScanner;
		table = new ATable();
		fillTable(bridge);
		threadNumber = 0;
		parser = new Parser(bridge);
	}
	
	public void setCommand(String newCommand){
		parser.setCommandText(newCommand);
		String oldCommand = command;
		command = newCommand;
		changes.notifyAllListeners(new PropertyChangeEvent(this, "command", oldCommand, newCommand));
		parser.getCommandObject().run();
	}
	
	public String getCommand(){
		return command;
	}
	
	@Tags({"asynchronousArthur"})
	public void animateArthur(){
		Thread thread = new Thread(new AnimateCommand(bridge, bridge.getArthur()));
		threadNumber++;
		thread.setName(ANIMATE_THREAD_NAME + " " + threadNumber);
		thread.start();
	}
	
	@Tags({"asynchronousLancelot"})
	public void animateLancelot(){
		Thread thread = new Thread(new AnimateCommand(bridge, bridge.getLancelot()));
		threadNumber++;
		thread.setName(ANIMATE_THREAD_NAME + " " + threadNumber);
		thread.start();
	}
	
	@Tags({"asynchronousGalahad"})
	public void animateGalahad(){
		Thread thread = new Thread(new AnimateCommand(bridge, bridge.getGalahad()));
		threadNumber++;
		thread.setName(ANIMATE_THREAD_NAME + " " + threadNumber);
		thread.start();
	}
	
	@Tags({"asynchronousRobin"})
	public void animateRobin(){
		Thread thread = new Thread(new AnimateCommand(bridge, bridge.getRobin()));
		threadNumber++;
		thread.setName(ANIMATE_THREAD_NAME + " " + threadNumber);
		thread.start();
	}
	
	private void fillTable(BridgeInterface initBridge){
		table.put("arthur", (Object) initBridge.getArthur());
		table.put("lancelot", (Object) initBridge.getLancelot());
		table.put("galahad", (Object) initBridge.getGalahad());
		table.put("robin", (Object) initBridge.getRobin());
		table.put("guard", (Object) initBridge.getGuard());
	}
	
	@Visible(false)
	public TableInterface getTable(){
		return table;
	}

	@Override
	public void addPropertyChangeListener(PropertyChangeListener listener) {
		changes.add(listener);
	}

	
}
