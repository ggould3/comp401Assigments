package mp.changeList;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public interface ChangeListInterface {

	public void notifyAllListeners(PropertyChangeEvent event);
	public int size();
	public void add(PropertyChangeListener propChange);
	public void remove(PropertyChangeListener propChange);
	public void remove(int index);
	public int indexOf(PropertyChangeListener propChange);
	public boolean isListening(PropertyChangeListener propChange);
	
}
