package mp.controller;

import java.awt.event.KeyListener;
import java.awt.event.MouseListener;

public interface BridgeControllerInterface  extends MouseListener, KeyListener{

}
