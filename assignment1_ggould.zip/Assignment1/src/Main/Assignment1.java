package Main;

import java.util.Scanner;

public class Assignment1 {
	
	static int tokens = 0;
	static int[] integerInputs = new int[20];
	static String repeat = "yes";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Please input your list of integers in a space separated list, use '.' to terminate the program.");
		while (repeat.equalsIgnoreCase("yes")){
			Assignment1.getInput();
			Assignment1.sumInts();
			Assignment1.productInts();
		}
	}

	public static void getInput(){
		Scanner keyboard = new Scanner(System.in);
		int subStart = 0;
		int subEnd;
		tokens = 0;
		int index = 0;
		
		String input = keyboard.nextLine();
		if (input.charAt(0) == '.'){
			System.out.println("Terminating Program");
			System.exit(0);
		}
		
		System.out.print("Numbers: ");
		
		while (index < input.length()){
			if (Character.isDigit(input.charAt(index))){
				int nextChar = index + 1;
				subStart = index;
				
				if (Character.isDigit(input.charAt(index)) && index == input.length()-1){  //Catches one-digit token in last index
					subEnd = index + 1;
					integerInputs[tokens] = Integer.parseInt(input.substring(subStart, subEnd)); //Places parsed substring in array
					System.out.print(integerInputs[tokens]+" ");
					tokens += 1;
					index += 1;
				}
				
				while (nextChar < input.length()){  //Catches token by detecting next non-digit
					if (!(Character.isDigit(input.charAt(nextChar)))){
						subEnd = nextChar;
						integerInputs[tokens] = Integer.parseInt(input.substring(subStart, subEnd));
						System.out.print(integerInputs[tokens]+" ");
						tokens += 1;
						index = nextChar + 1; //Jump ahead in input string to not re-scan characters
						break;
					}else if (nextChar == input.length()-1 && Character.isDigit(input.charAt(nextChar))){ //Catches multi-digit token in last index
						subEnd = nextChar+1;
						integerInputs[tokens] = Integer.parseInt(input.substring(subStart, subEnd));
						System.out.print(integerInputs[tokens]+" ");
						tokens += 1;
						index = nextChar + 1;
						break;
					}else{
						nextChar++;
					}
				}
			}else{
				index++;
			}
		}
	}
	
	public static void sumInts(){
		int sum = 0;

		for (int i=0; i<tokens; i++){
			sum += integerInputs[i];
		}
		
		System.out.print("Sum: "+sum+" ");
	}
	
	public static void productInts(){
		int product = 1;
		
		for (int i=0; i<tokens; i++){
			product *= integerInputs[i];
		}
		
		System.out.println("Product: "+product);
	}
}
