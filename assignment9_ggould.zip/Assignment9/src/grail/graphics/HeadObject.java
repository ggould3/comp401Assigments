package grail.graphics;

import java.beans.PropertyChangeEvent;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;

import javax.swing.ImageIcon;

@StructurePattern(StructurePatternNames.IMAGE_PATTERN)
@PropertyNames({"X", "Y", "ImageFileName", "Height", "Width"})
@EditablePropertyNames({"X", "Y", "ImageFileName", "Height", "Width"})

public class HeadObject extends ABoundedShape implements ImageShapeInterface{

	String imageFileName;
    
    public HeadObject(){
    	x = 0;
    	y = 0;
    	imageFileName = "";
    	height = 0;
    	width = 0;
    }
    
    public HeadObject (String image, int initX, int initY) {	
    	
    	imageFileName = image;
    	ImageIcon icon = new ImageIcon("src/"+imageFileName);
    	height = icon.getIconHeight();
    	width = icon.getIconWidth();
    	x = initX;
    	y = initY;      
    }   
	
	public String getImageFileName() {
		return imageFileName;
	}
	
	public void setImageFileName(String newVal) {
		String oldVal = imageFileName;
		imageFileName = newVal;
		changes.notifyAllListeners(new PropertyChangeEvent(this, "Text", oldVal, newVal));
	}   
}
