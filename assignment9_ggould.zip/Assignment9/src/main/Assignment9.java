package main;

import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JTextField;

import util.misc.ThreadSupport;
import bus.uigen.OEFrame;
import bus.uigen.ObjectEditor;
import mp.bridge.*;
import mp.controller.BridgeControllerInterface;
import mp.controller.BridgeSceneController;
import mp.controller.CommandInterpreterController;
import mp.interpreter.AnInterpreter;
import mp.interpreter.InterpreterInterface;
import mp.painter.ScenePainter;
import mp.scanner.*;

public class Assignment9 {

	final static int WINDOW_X = 1100;
	final static int WINDOW_Y = 700;
	final static int LOCATION_X_Y = 0;
	final static int SLEEP = 2000;
	final static int SCANNER_X = 400;
	
	public static void main(String[] args) {
		ScannerInterface scanner = new ScannerBean();
		BridgeInterface bridge = new BridgeScene();
		InterpreterInterface interpreter = new AnInterpreter(bridge, scanner);
		
		//Set location for bridge window, approach, then stop
		OEFrame bridgeEditor = ObjectEditor.edit(bridge);
		bridgeEditor.setSize(WINDOW_X, WINDOW_Y);
		bridgeEditor.setLocation(LOCATION_X_Y, LOCATION_X_Y);
		
		//Main scene view
		PropertyChangeListener painter = new ScenePainter(bridge);
		JFrame frame = new JFrame("Bridge Scene");
		frame.add((Component) painter);
		frame.setSize(WINDOW_X, WINDOW_Y);
		frame.setVisible(true);
		
		//Interpreter view
		JFrame frame2 = new JFrame("Command Interpreter");
		frame2.setLayout(new GridLayout(3,1));
		JTextField textField = new JTextField();
		JButton button = new JButton("Move all right by 10");
		JMenuItem menuItem = new JMenuItem("Move all down by 10");
		frame2.add(textField);
		frame2.add(button);
		frame2.add(menuItem);
		frame2.setSize(400,150);
		frame2.setLocation(600, 0);
		frame2.setVisible(true);
		
		BridgeControllerInterface controller = new BridgeSceneController(bridge, (Component) painter);
		ActionListener commandController = new CommandInterpreterController(interpreter, textField, button, menuItem);
		
		ThreadSupport.sleep(SLEEP);
		bridge.approachBridge(bridge.getRobin());
		ThreadSupport.sleep(SLEEP);
		bridge.sayString("Hello there, can you see me now?");
		ThreadSupport.sleep(SLEEP);
		bridge.sayString("Why yes I can!");
		ThreadSupport.sleep(SLEEP);
		bridge.sayString("How wonderful!");
		ThreadSupport.sleep(SLEEP);
		bridge.failed();
		ThreadSupport.sleep(SLEEP);
		bridge.sayString("Ahhhhhhh!");
	}
}
