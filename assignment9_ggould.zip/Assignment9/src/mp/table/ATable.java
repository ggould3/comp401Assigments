package mp.table;

import java.util.ArrayList;

import util.annotations.Tags;

@Tags({"Table"})
public class ATable implements TableInterface{

	ArrayList<String> keyList;
	ArrayList<Object> valueList;
	
	public ATable(){
		keyList = new ArrayList<String>();
		valueList = new ArrayList<Object>();
	}
	
	public void put(String key, Object val) {
		if(key == null || val == null){
			//Do nothing
		}else if(keyList.contains(key)){
			int index = keyList.indexOf(key);
			valueList.set(index, val);
		}else{
			keyList.add(key);
			valueList.add(val);
		}
	}

	public Object get(String key) {
		int index = keyList.indexOf(key);
		Object value = valueList.get(index);
		return value;
	}
}
