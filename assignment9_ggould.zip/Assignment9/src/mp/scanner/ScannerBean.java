package mp.scanner;

import grail.tokens.*;
import util.annotations.StructurePattern;

@StructurePattern("Bean Pattern")

public class ScannerBean implements ScannerInterface{
	String scannedString = "";
	TokenInterface[] largeTokenArray = new TokenInterface[100];
	TokenInterface[] tokenArray = {};
	int tokens;
	
	public void setScannedString(String inputString){
		scannedString = inputString;
		String input = scannedString;
		
		tokens = 0;
		
		int index = 0;
		int subStart;
		int subEnd;
		
		while (index < input.length()){
			if (input.charAt(index) == '.'){ 	//Terminates on '.'
				System.out.println("Terminating program.");
				break;
			}else if (input.charAt(index) == '{'){ 	//Grabs Start Tokens
				subStart = index;
				subEnd = index + 1;
				TokenInterface mySToken = new StartToken(input.substring(subStart,subEnd));
				largeTokenArray[tokens] = mySToken;
				tokens++;
				index += 1;
			}else if (input.charAt(index) == '}'){ 	//Grabs End Tokens
				subStart = index;
				subEnd = index + 1;
				TokenInterface myEToken = new EndToken(input.substring(subStart,subEnd));
				largeTokenArray[tokens] = myEToken;
				tokens++;
				index += 1;
			}else if (input.charAt(index) == '+'){ 	//Grabs Plus Tokens
				subStart = index;
				subEnd = index + 1;
				TokenInterface myPToken = new PlusToken(input.substring(subStart,subEnd));
				largeTokenArray[tokens] = myPToken;
				tokens++;
				index += 1;
			}else if (input.charAt(index) == '-'){ 	//Grabs Minus Tokens
				subStart = index;
				subEnd = index + 1;
				TokenInterface myMToken = new MinusToken(input.substring(subStart,subEnd));
				largeTokenArray[tokens] = myMToken;
				tokens++;
				index += 1;
			}else if (Character.isDigit(input.charAt(index))){ 	//Grabs Numbers
				subStart = index;
				int nextChar = index + 1;
				
				if (index == (input.length()-1)){
					subEnd = nextChar;					
					createNumberObject(input.substring(subStart,subEnd));	
					tokens++;
					index = nextChar;
					break;
				}
				
				while (nextChar < input.length()){
					if(Character.isDigit(input.charAt(nextChar)) && nextChar == (input.length()-1)){
						subEnd = nextChar+1;						
						createNumberObject(input.substring(subStart,subEnd));
						tokens++;
						index = nextChar + 1;
						break;
					}else if (Character.isDigit(input.charAt(nextChar)) && nextChar < input.length()){
						nextChar++;
					}else{
						subEnd = nextChar;						
						createNumberObject(input.substring(subStart,subEnd));	
						tokens++;
						index = nextChar;
						break;
					}
				}
			}else if(input.charAt(index)=='"'){ 	//Grabs Quotes
				subStart = index;
				int nextChar = index + 1;
				
				while (nextChar < input.length()){
					if (input.charAt(nextChar) == '"'){
						subEnd = nextChar;
						createQuoteObject(input.substring(subStart,subEnd+1));
						tokens++;
						index = nextChar + 1;
						break;
					}else if (nextChar == (input.length()-1) && !(input.charAt(nextChar) == '"')){
						System.out.println("Error: no closing quotation found.");
						return;
					}else{
						nextChar++;
					}
				}
			}else if (Character.isLetter(input.charAt(index))){ 	//Grabs Words
				subStart = index;
				int nextChar = index + 1;
				
				if (index == (input.length()-1)){
					subEnd = nextChar;
					checkForCommand(input.substring(subStart,subEnd));
					tokens++;
					index = nextChar;
					break;
				}
				
				while (nextChar < input.length()){
					if(Character.isLetter(input.charAt(nextChar)) && nextChar == (input.length()-1)){
						subEnd = nextChar+1;
						checkForCommand(input.substring(subStart,subEnd));
						tokens++;
						index = nextChar + 1;
						break;
					}else if (Character.isLetter(input.charAt(nextChar)) && nextChar < input.length()){
						nextChar++;
					}else{
						subEnd = nextChar;
						checkForCommand(input.substring(subStart,subEnd));
						tokens++;
						index = nextChar;
						break;
					}
				}
			}else{
				index++;
			}
		}
		tokenArray = new TokenInterface[tokens];
		int tokenArrayIndex = 0;
		while (tokenArrayIndex < tokens){
			tokenArray[tokenArrayIndex] = largeTokenArray[tokenArrayIndex];
			tokenArrayIndex++;
		}
	}
	
	public String getScannedString(){
		return scannedString;
	}
	
	public TokenInterface[] getTokens(){
		return tokenArray;
	}
	
	private void createNumberObject(String inputSubstring){
		NumberInterface myNumToken = new NumberToken(inputSubstring);
		largeTokenArray[tokens] = myNumToken;
	}
	
	private void createWordObject(String inputSubstring){
		WordInterface myWToken = new WordToken(inputSubstring);
		largeTokenArray[tokens] = myWToken;
	}
	
	private void createQuoteObject(String inputSubstring){
		QuoteInterface myQToken = new QuoteToken(inputSubstring);
		largeTokenArray[tokens] = myQToken;
	}
	
	private void checkForCommand(String input){
		String command = input.toLowerCase();
		switch (command){
			case "approach":
				WordInterface myAppToken = new CommandApproach(input);
				largeTokenArray[tokens] = myAppToken;
				break;
			case "call":
				WordInterface myCallToken = new CommandCall(input);
				largeTokenArray[tokens] = myCallToken;
				break;
			case "move":
				WordInterface myMoveToken = new CommandMove(input);
				largeTokenArray[tokens] = myMoveToken;
				break;
			case "proceedall":
				WordInterface myProToken = new CommandProceedAll(input);
				largeTokenArray[tokens] = myProToken;
				break;
			case "redo":
				WordInterface myRedoToken = new CommandRedo(input);
				largeTokenArray[tokens] = myRedoToken;
				break;
			case "repeat":
				WordInterface myRepeatToken = new CommandRepeat(input);
				largeTokenArray[tokens] = myRepeatToken;
				break;
			case "rotateleftarm":
				WordInterface myRLAToken = new CommandRotateLeftArm(input);
				largeTokenArray[tokens] = myRLAToken;
				break;
			case "rotaterightarm":
				WordInterface myRRAToken = new CommandRotateRightArm(input);
				largeTokenArray[tokens] = myRRAToken;
				break;
			case "say":
				WordInterface mySayToken = new CommandSay(input);
				largeTokenArray[tokens] = mySayToken;
				break;
			case "sleep":
				WordInterface mySleepToken = new CommandSleep(input);
				largeTokenArray[tokens] = mySleepToken;
				break;
			case "thread":
				WordInterface myThreadToken = new CommandThread(input);
				largeTokenArray[tokens] = myThreadToken;
				break;
			case "undo":
				WordInterface myUndoToken = new CommandUndo(input);
				largeTokenArray[tokens] = myUndoToken;
				break;
			case "wait":
				WordInterface myWaitToken = new CommandWait(input);
				largeTokenArray[tokens] = myWaitToken;
				break;
			default:
				createWordObject(input);
				break;
		}
	}
}