package mp.bridge;

import grail.graphics.*;

public interface BridgeInterface {

	AvatarInterface getArthur();
	AvatarInterface getLancelot();
	AvatarInterface getGalahad();
	AvatarInterface getRobin();
	AvatarInterface getGuard();
	GorgeInterface getGorge();
	OvalShapeInterface getKnightArea();
	OvalShapeInterface getGuardArea();
	boolean getOccupied();
	void approachBridge(AvatarInterface avatar);
	void sayString(String text);
	void passed();
	void failed();
	
}
