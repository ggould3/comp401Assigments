package mp.bridge;

import grail.graphics.*;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;
import util.annotations.Visible;

@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Arthur", "Lancelot", "Galahad", "Robin", "Guard", "Gorge", "KnightArea", "GuardArea"})

@Tags({"BridgeScene"})
public class BridgeScene implements BridgeInterface{

	AvatarInterface arthur;
	AvatarInterface lancelot;
	AvatarInterface galahad;
	AvatarInterface robin;
	AvatarInterface guard;
	
	GorgeInterface gorge;
	OvalShapeInterface knightArea;
	OvalShapeInterface guardArea;
	
	boolean occupied = false;
	AvatarInterface knightInArea;
	boolean knightTurn = false;
	
	int knightAreaX = 430;
	int knightAreaY = 290;
	
	//Guard Area Location: 585, 290
	//Knight Area Location: 430, 290
	public BridgeScene(){
		arthur = new AvatarCompositeObject("arthur.jpg", 40, 20);
		lancelot = new AvatarCompositeObject("lancelot.jpg", 190, 20);
		galahad = new AvatarCompositeObject("galahad.jpg", 190, 220);
		robin = new AvatarCompositeObject("robin.jpg", 40, 220);
		guard = new AvatarCompositeObject("guard.jpg", 585, 290);
		
		gorge = new GorgeCompositeObject();
		knightArea = new OvalObject(400, 450, 100, 50);
		guardArea = new OvalObject(550, 450, 100, 50);
		
		occupied = false;
		knightInArea = null;
		knightTurn = false;
	}
	
	@Tags({"approach"})
	public void approachBridge(AvatarInterface avatar){
		if (occupied == false){
			int avatarStartX = avatar.getHead().getX();
			int avatarStartY = avatar.getHead().getY();

			avatar.moveAvatar(knightAreaX - avatarStartX, knightAreaY - avatarStartY);
			occupied = true;
			knightInArea = avatar;
		}else{
			//do nothing
		}
	}
	
	@Tags({"say"})
	public void sayString(String text){
		if(occupied == true){
			if(knightTurn == false){
				guard.getText().setText(text);
				knightTurn = true;
			}else{
				knightInArea.getText().setText(text);
				knightTurn = false;
			}
		}else{
			//do nothing
		}
	}
	
	@Tags({"passed"})
	public void passed(){
		if(occupied == true && knightTurn == false){
			knightInArea.moveAvatar(550, 0);
			occupied = false;
			knightInArea = null;
		}else{
			//do nothing
		}
	}
	
	@Tags({"failed"})
	public void failed(){
		if(occupied == true){
			if(knightTurn == true){
				guard.moveAvatar(200, -140);
				knightTurn = false;
			}else{
				knightInArea.moveAvatar(350, 240);
				occupied = false;
			}
		}else{
			//do nothing
		}
	}
	
	public AvatarInterface getArthur(){
		return arthur;
	}
	
	public AvatarInterface getLancelot(){
		return lancelot;
	}
	
	public AvatarInterface getGalahad(){
		return galahad;
	}
	
	public AvatarInterface getRobin(){
		return robin;
	}
	
	public AvatarInterface getGuard(){
		return guard;
	}

	public GorgeInterface getGorge(){
		return gorge;
	}
	
	@Tags({"KnightArea"})
	public OvalShapeInterface getKnightArea(){
		return knightArea;
	}
	
	@Tags({"GuardArea"})
	public OvalShapeInterface getGuardArea(){
		return guardArea;
	}
	
	@Visible(false)
	public boolean getOccupied(){
		return occupied;
	}
	
	@Visible(false)
	public boolean getKnightTurn(){
		return knightTurn;
	}
}
