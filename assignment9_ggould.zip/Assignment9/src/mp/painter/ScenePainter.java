package mp.painter;

import grail.graphics.ImageShapeInterface;
import grail.graphics.LineShapeInterface;
import grail.graphics.OvalShapeInterface;
import grail.graphics.StringShapeInterface;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import mp.bridge.BridgeInterface;
import util.annotations.Tags;
import util.models.PropertyListenerRegisterer;

@Tags({"InheritingBridgeScenePainter"})
public class ScenePainter extends Component implements PropertyChangeListener{

	//Weird required long
	private static final long serialVersionUID = 1L;
	
	BasicStroke dotted = new BasicStroke(5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 
            5f, new float[] {2f}, 0f);
	
	BridgeInterface scene;
	
	public ScenePainter(BridgeInterface theScene){
		scene = theScene;
		setFocusable(true);
		scene.getArthur().getHead().addPropertyChangeListener(this);
			scene.getArthur().getArms().getLeftLine().addPropertyChangeListener(this);
			scene.getArthur().getArms().getRightLine().addPropertyChangeListener(this);
			scene.getArthur().getBody().addPropertyChangeListener(this);
			scene.getArthur().getLegs().getLeftLine().addPropertyChangeListener(this);
			scene.getArthur().getLegs().getRightLine().addPropertyChangeListener(this);
			scene.getArthur().getText().addPropertyChangeListener(this);
		scene.getGalahad().getHead().addPropertyChangeListener(this);
			scene.getGalahad().getArms().getLeftLine().addPropertyChangeListener(this);
			scene.getGalahad().getArms().getRightLine().addPropertyChangeListener(this);
			scene.getGalahad().getBody().addPropertyChangeListener(this);
			scene.getGalahad().getLegs().getLeftLine().addPropertyChangeListener(this);
			scene.getGalahad().getLegs().getRightLine().addPropertyChangeListener(this);
			scene.getGalahad().getText().addPropertyChangeListener(this);
		scene.getGuard().getHead().addPropertyChangeListener(this);
			scene.getGuard().getArms().getLeftLine().addPropertyChangeListener(this);
			scene.getGuard().getArms().getRightLine().addPropertyChangeListener(this);
			scene.getGuard().getBody().addPropertyChangeListener(this);
			scene.getGuard().getLegs().getLeftLine().addPropertyChangeListener(this);
			scene.getGuard().getLegs().getRightLine().addPropertyChangeListener(this);
			scene.getGuard().getText().addPropertyChangeListener(this);
		scene.getLancelot().getHead().addPropertyChangeListener(this);
			scene.getLancelot().getArms().getLeftLine().addPropertyChangeListener(this);
			scene.getLancelot().getArms().getRightLine().addPropertyChangeListener(this);
			scene.getLancelot().getBody().addPropertyChangeListener(this);
			scene.getLancelot().getLegs().getLeftLine().addPropertyChangeListener(this);
			scene.getLancelot().getLegs().getRightLine().addPropertyChangeListener(this);
			scene.getLancelot().getText().addPropertyChangeListener(this);
		scene.getRobin().getHead().addPropertyChangeListener(this);
			scene.getRobin().getArms().getLeftLine().addPropertyChangeListener(this);
			scene.getRobin().getArms().getRightLine().addPropertyChangeListener(this);
			scene.getRobin().getBody().addPropertyChangeListener(this);
			scene.getRobin().getLegs().getLeftLine().addPropertyChangeListener(this);
			scene.getRobin().getLegs().getRightLine().addPropertyChangeListener(this);
			scene.getRobin().getText().addPropertyChangeListener(this);
	}
	
	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		repaint();
	}
	
	public void register (PropertyListenerRegisterer aPropertyChangeRegister){
		aPropertyChangeRegister.addPropertyChangeListener(this);        
	}
	
	public void paint(Graphics g){
		super.paint(g);
        Graphics2D g2 = (Graphics2D) g; 
        g2.setStroke(dotted);
        g.setColor(Color.BLACK);
        draw(g2, scene);
	}
	
	public void draw(Graphics2D g, BridgeInterface scene){
		//Draw the Gorge
		draw(g, scene.getGorge().getBridgeBottom());
		draw(g, scene.getGorge().getBridgeTop());
		draw(g, scene.getGorge().getLeftCliff());
		draw(g, scene.getGorge().getRightCliff());
		//Knight/Guard Area
		draw(g, scene.getGuardArea());
		draw(g, scene.getKnightArea());
		//Arthur
		draw(g, scene.getArthur().getText());
		draw(g, scene.getArthur().getHead());
		draw(g, scene.getArthur().getArms().getLeftLine());
		draw(g, scene.getArthur().getArms().getRightLine());
		draw(g, scene.getArthur().getLegs().getLeftLine());
		draw(g, scene.getArthur().getLegs().getRightLine());
		draw(g, scene.getArthur().getBody());
		//Lancelot
		draw(g, scene.getLancelot().getText());
		draw(g, scene.getLancelot().getHead());
		draw(g, scene.getLancelot().getArms().getLeftLine());
		draw(g, scene.getLancelot().getArms().getRightLine());
		draw(g, scene.getLancelot().getLegs().getLeftLine());
		draw(g, scene.getLancelot().getLegs().getRightLine());
		draw(g, scene.getLancelot().getBody());
		//Galahad
		draw(g, scene.getGalahad().getText());
		draw(g, scene.getGalahad().getHead());
		draw(g, scene.getGalahad().getArms().getLeftLine());
		draw(g, scene.getGalahad().getArms().getRightLine());
		draw(g, scene.getGalahad().getLegs().getLeftLine());
		draw(g, scene.getGalahad().getLegs().getRightLine());
		draw(g, scene.getGalahad().getBody());
		//Robin
		draw(g, scene.getRobin().getText());
		draw(g, scene.getRobin().getHead());
		draw(g, scene.getRobin().getArms().getLeftLine());
		draw(g, scene.getRobin().getArms().getRightLine());
		draw(g, scene.getRobin().getLegs().getLeftLine());
		draw(g, scene.getRobin().getLegs().getRightLine());
		draw(g, scene.getRobin().getBody());
		//Guard
		draw(g, scene.getGuard().getText());
		draw(g, scene.getGuard().getHead());
		draw(g, scene.getGuard().getArms().getLeftLine());
		draw(g, scene.getGuard().getArms().getRightLine());
		draw(g, scene.getGuard().getLegs().getLeftLine());
		draw(g, scene.getGuard().getLegs().getRightLine());
		draw(g, scene.getGuard().getBody());
	}
	
	public void draw(Graphics g, LineShapeInterface line){
		g.drawLine(line.getX(), line.getY(), line.getX()+line.getWidth(), line.getY()+line.getHeight());
	}
	
	public void draw(Graphics g, OvalShapeInterface oval){
		g.drawOval(oval.getX(), oval.getY(), oval.getWidth(), oval.getHeight());
	}
	
	public void draw(Graphics2D g, ImageShapeInterface image){
		Image img = Toolkit.getDefaultToolkit().getImage("src/"+image.getImageFileName());
		g.drawImage(img, image.getX(), image.getY(), image.getWidth(), image.getHeight(), this);
	}
	
	public void draw(Graphics g, StringShapeInterface string){
		g.drawString(string.getText(), string.getX(), string.getY());
	}

}
