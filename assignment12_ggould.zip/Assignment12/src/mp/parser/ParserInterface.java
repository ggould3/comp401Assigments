package mp.parser;

import mp.table.TableInterface;
import grail.graphics.AvatarInterface;
import grail.tokens.TokenInterface;

public interface ParserInterface {

	void setCommandText(String newCommand);
	String getCommandText();
	Runnable getCommandObject();
	Runnable parseCommand(TokenInterface[] tokenArray);
	Runnable createSay(TokenInterface[] tokenArray);
	Runnable createMove(TokenInterface[] tokenArray);
	Runnable createApproach(TokenInterface[] tokenArray);
	Runnable createPass(TokenInterface[] tokenArray);
	Runnable createFail(TokenInterface[] tokenArray);
	Runnable createCommandList(TokenInterface[] tokenArray);
	Runnable createRepeat(TokenInterface[] tokenArray);
	TableInterface<AvatarInterface> getTable();
}
