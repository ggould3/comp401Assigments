package mp.clearanceManager;

public interface BroadcastingClearanceManager extends ClearanceManager {
	public void proceedAll();

}
