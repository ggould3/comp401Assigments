package mp.clearanceManager;

public interface ClearanceManager {
	public void proceed();
	public void waitForProceed();	
	

}
