package mp.interpreter;

import java.awt.event.ActionEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import grail.commands.AnimateCommand;
import grail.commands.MoveCommand;
import grail.commands.SayCommand;
import grail.graphics.AvatarInterface;
import grail.tokens.CommandMove;
import grail.tokens.CommandSay;
import grail.tokens.NumberInterface;
import grail.tokens.QuoteInterface;
import grail.tokens.TokenInterface;
import grail.tokens.WordInterface;
import grail.tokens.WordToken;
import mp.bridge.BridgeInterface;
import mp.changeList.ChangeList;
import mp.changeList.ChangeListInterface;
import mp.clearanceManager.BroadcastingClearanceManager;
import mp.parser.Parser;
import mp.parser.ParserInterface;
import mp.scanner.ScannerInterface;
import mp.table.ATable;
import mp.table.TableInterface;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePatternNames;
import util.annotations.StructurePattern;
import util.annotations.Tags;
import util.annotations.Visible;

@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Command", "Table"})
@EditablePropertyNames({"Command"})
@Tags({"CommandInterpreter"})
public class AnInterpreter implements InterpreterInterface{

	ScannerInterface scanner;
	BridgeInterface bridge;
	String command = "";
	TokenInterface[] tokens = {new WordToken()};
	final static String ANIMATE_THREAD_NAME = "Avatar animation thread";
	int threadNumber;
	ParserInterface parser;
	ChangeListInterface changes = new ChangeList();
	BroadcastingClearanceManager clear;
	
	public AnInterpreter(BridgeInterface initBridge, ScannerInterface initScanner, BroadcastingClearanceManager initClear){
		bridge = initBridge;
		scanner = initScanner;
		threadNumber = 0;
		parser = new Parser(bridge);
		clear = initClear;
		
	}
	
	public void setCommand(String newCommand){
		parser.setCommandText(newCommand);
		String oldCommand = command;
		command = newCommand;
		changes.notifyAllListeners(new PropertyChangeEvent(this, "command", oldCommand, newCommand));
		parser.getCommandObject().run();
	}
	
	public String getCommand(){
		return command;
	}
	
	@Tags({"asynchronousArthur"})
	public void animateArthur(){
		Thread thread = new Thread(new AnimateCommand(bridge, bridge.getArthur()));
		threadNumber++;
		thread.setName(ANIMATE_THREAD_NAME + " " + threadNumber);
		thread.start();
	}
	
	@Tags({"asynchronousLancelot"})
	public void animateLancelot(){
		Thread thread = new Thread(new AnimateCommand(bridge, bridge.getLancelot()));
		threadNumber++;
		thread.setName(ANIMATE_THREAD_NAME + " " + threadNumber);
		thread.start();
	}
	
	@Tags({"asynchronousGalahad"})
	public void animateGalahad(){
		Thread thread = new Thread(new AnimateCommand(bridge, bridge.getGalahad()));
		threadNumber++;
		thread.setName(ANIMATE_THREAD_NAME + " " + threadNumber);
		thread.start();
	}
	
	@Tags({"asynchronousRobin"})
	public void animateRobin(){
		Thread thread = new Thread(new AnimateCommand(bridge, bridge.getRobin()));
		threadNumber++;
		thread.setName(ANIMATE_THREAD_NAME + " " + threadNumber);
		thread.start();
	}
	
	@Tags({"waitingArthur"})
	public void waitingArthur(){
		Thread thread = new Thread(new AnimateCommand(bridge, bridge.getArthur(), clear));
		threadNumber++;
		thread.setName(ANIMATE_THREAD_NAME + " " + threadNumber);
		thread.start();
	}
	
	@Tags({"waitingLancelot"})
	public void waitingLancelot(){
		Thread thread = new Thread(new AnimateCommand(bridge, bridge.getLancelot(), clear));
		threadNumber++;
		thread.setName(ANIMATE_THREAD_NAME + " " + threadNumber);
		thread.start();
	}
	
	@Tags({"waitingGalahad"})
	public void waitingGalahad(){
		Thread thread = new Thread(new AnimateCommand(bridge, bridge.getGalahad(), clear));
		threadNumber++;
		thread.setName(ANIMATE_THREAD_NAME + " " + threadNumber);
		thread.start();
	}
	
	@Tags({"waitingRobin"})
	public void waitingRobin(){
		Thread thread = new Thread(new AnimateCommand(bridge, bridge.getRobin(), clear));
		threadNumber++;
		thread.setName(ANIMATE_THREAD_NAME + " " + threadNumber);
		thread.start();
	}
	
	@Tags({"startAnimation"})
	public void startAnimation(){
		clear.proceedAll();
	}

	@Override
	public void addPropertyChangeListener(PropertyChangeListener listener) {
		changes.add(listener);
	}

	
}
