package mp.table;

import java.util.ArrayList;

import util.annotations.Tags;

@Tags({"generic"})
public class ATable<T> implements TableInterface<T>{

	ArrayList<String> keyList;
	ArrayList<T> valueList;
	
	public ATable(){
		keyList = new ArrayList<String>();
		valueList = new ArrayList<T>();
	}
	
	public void put(String key, T val) {
		if(key == null || val == null){
			//Do nothing
		}else if(keyList.contains(key)){
			int index = keyList.indexOf(key);
			valueList.set(index, val);
		}else{
			keyList.add(key);
			valueList.add(val);
		}
	}

	public T get(String key) {
		int index = keyList.indexOf(key);
		T value = valueList.get(index);
		return value;
	}
}
