package mp.table;

import util.annotations.Tags;

@Tags({"generic"})
public interface TableInterface<T> {

	void put(String key, T val);
	T get(String key);
}
