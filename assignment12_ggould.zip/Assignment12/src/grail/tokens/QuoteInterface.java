package grail.tokens;

public interface QuoteInterface extends TokenInterface{
	String getValue();
}
