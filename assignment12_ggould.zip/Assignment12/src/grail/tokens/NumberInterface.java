package grail.tokens;

public interface NumberInterface extends TokenInterface{
	int getValue();
}
