package grail.graphics;

public interface GorgeInterface {

	LineShapeInterface getLeftCliff();
	LineShapeInterface getRightCliff();
	LineShapeInterface getBridgeTop();
	LineShapeInterface getBridgeBottom();
}
