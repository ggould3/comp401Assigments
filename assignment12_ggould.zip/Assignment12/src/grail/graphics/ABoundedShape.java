package grail.graphics;

import java.beans.PropertyChangeEvent;

import util.annotations.Tags;

@Tags({"BoundedShape"})
public abstract class ABoundedShape extends ALocatable implements BoundedShapeInterface{

	int width, height;
	
	public void setWidth(int newWidth){
		int oldWidth = getWidth();
		width = newWidth;
		changes.notifyAllListeners(new PropertyChangeEvent(this, "Width", oldWidth, newWidth));
	}
	
	public void setHeight(int newHeight){
		int oldHeight = getHeight();
		height = newHeight;
		changes.notifyAllListeners(new PropertyChangeEvent(this, "Height", oldHeight, newHeight));
	}
	
	public int getWidth(){
		return width;
	}
	
	public int getHeight(){
		return height;
	}
}
