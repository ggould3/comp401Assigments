package grail.graphics;

public interface ImageShapeInterface extends BoundedShapeInterface{
	
	String getImageFileName();
	void setImageFileName(String Image);

}
