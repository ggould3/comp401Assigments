package grail.graphics;

import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;

@StructurePattern(StructurePatternNames.LINE_PATTERN)
@PropertyNames({"X", "Y", "Width", "Height"})
@EditablePropertyNames({"X", "Y", "Width", "Height"})

public class LineObject extends ABoundedShape implements LineShapeInterface{

	public LineObject(){
		x = 0;
		y = 0;
		width = 10;
		height = 10;
	}
	
	public LineObject (int X, int Y, int Width, int Height) {
		x = X; 
		y = Y;
		width = Width;
		height = Height;	
	}
}
