package grail.commands;

import java.util.ArrayList;
import java.util.List;

import util.annotations.Tags;

@Tags({"CommandList"})
public class CommandList implements CommandListInterface{

	List<Runnable> commandList;
	
	public CommandList(){
		commandList = new ArrayList<>();
	}
	
	@Tags({"add"})
	public void add(Runnable newCommand){
		commandList.add(newCommand);
	}
	
	public void run(){
		for(int i=0; i<commandList.size(); i++){
			commandList.get(i).run();
		}
	}
}
