package grail.commands;

import util.annotations.Tags;
import mp.bridge.BridgeInterface;

@Tags({"PassCommand"})
public class PassCommand implements Runnable{
	
	BridgeInterface scene;
	
	public PassCommand(BridgeInterface scene){
		this.scene = scene;
	}
	
	public void run(){
		scene.passed();
	}

}
