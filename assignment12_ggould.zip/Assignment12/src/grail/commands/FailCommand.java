package grail.commands;

import util.annotations.Tags;
import mp.bridge.BridgeInterface;

@Tags({"FailCommand"})
public class FailCommand implements Runnable{
	
	BridgeInterface scene;
	
	public FailCommand(BridgeInterface scene){
		this.scene = scene;
	}
	
	public void run(){
		scene.failed();
	}

}
