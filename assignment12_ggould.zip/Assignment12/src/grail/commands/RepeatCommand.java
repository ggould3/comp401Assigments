package grail.commands;

import util.annotations.Tags;

@Tags({"Repeat"})
public class RepeatCommand implements Runnable{
	
	int numRepeats;
	Runnable command;
	boolean validNum;
	
	public RepeatCommand(int numRepeats, Runnable command){
		this.numRepeats = numRepeats;
		this.command = command;
		if(numRepeats > 0){
			validNum = true;
		}else{
			validNum = false;
		}
	}
	
	public void run(){
		if(!validNum){
			return;
		}
		
		for(int i=0; i<numRepeats; i++){
			command.run();
		}
	}

}
