package grail.commands;

public interface CommandListInterface extends Runnable{

	void add(Runnable newCommand);
	
}
