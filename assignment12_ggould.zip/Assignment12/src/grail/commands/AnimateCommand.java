package grail.commands;

import mp.animator.ArthurAnimator;
import mp.animator.AvatarAnimator;
import mp.animator.GalahadAnimator;
import mp.animator.LancelotAnimator;
import mp.animator.RobinAnimator;
import mp.bridge.BridgeInterface;
import mp.clearanceManager.BroadcastingClearanceManager;
import grail.graphics.AvatarInterface;
import util.annotations.Tags;

@Tags({"AnimatingCommand"})
public class AnimateCommand implements Runnable{

	AvatarInterface avatar;
	BridgeInterface scene;
	BroadcastingClearanceManager clear = null;
	
	public AnimateCommand(BridgeInterface scene, AvatarInterface avatar){
		this.avatar = avatar;
		this.scene = scene;
	}
	
	public AnimateCommand(BridgeInterface scene, AvatarInterface avatar, BroadcastingClearanceManager clear){
		this.avatar = avatar;
		this.scene = scene;
		this.clear = clear;
	}
	
	public void run(){
		if(clear != null){
			clear.waitForProceed();
		}
		
		if(avatar == scene.getArthur()){
			ArthurAnimator.animateAvatar(avatar);
		}else if(avatar == scene.getLancelot()){
			LancelotAnimator.animateAvatar(avatar);
		}else if(avatar == scene.getGalahad()){
			GalahadAnimator.animateAvatar(avatar);
		}else if(avatar == scene.getRobin()){
			RobinAnimator.animateAvatar(avatar);
		}
	}
}
